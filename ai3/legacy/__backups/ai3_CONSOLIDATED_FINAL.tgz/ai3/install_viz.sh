
#!/usr/bin/env zsh
# install_viz.sh - AI3 Babylon.js Visualizer Installer

# This script sets up a visualization environment using Babylon.js to render AI3's heart/brain, allowing for efficient communication and understanding of AI3's tasks and states.

# Define directories and variables
PROJECT_DIR="${HOME}/ai3_viz"
LOG_FILE="${PROJECT_DIR}/ai3_viz_install.log"

# Step 1: Install Node.js and npm (required for Babylon.js)
echo "Installing Node.js and npm..." | tee -a $LOG_FILE
pkg_add node

# Step 2: Create project folder and initialize npm project
mkdir -p $PROJECT_DIR
cd $PROJECT_DIR

echo "Initializing npm project..." | tee -a $LOG_FILE
npm init -y

# Step 3: Install Babylon.js and dependencies
echo "Installing Babylon.js and dependencies..." | tee -a $LOG_FILE
npm install babylonjs

# Step 4: Create visualization script using Babylon.js
echo "Creating Babylon.js visualization script..." | tee -a $LOG_FILE
cat <<'EOF' > $PROJECT_DIR/index.html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI3 Brain Visualization</title>
  <script src="node_modules/babylonjs/babylon.js"></script>
  <style>
    body { margin: 0; overflow: hidden; }
    canvas { width: 100vw; height: 100vh; display: block; }
  </style>
</head>
<body>
  <canvas id="renderCanvas"></canvas>

  <script>
    // Initialize Babylon.js engine and scene
    const canvas = document.getElementById('renderCanvas');
    const engine = new BABYLON.Engine(canvas, true);
    const scene = new BABYLON.Scene(engine);

    // Create a camera and a light
    const camera = new BABYLON.ArcRotateCamera("Camera", Math.PI / 2, Math.PI / 2, 2, BABYLON.Vector3.Zero(), scene);
    camera.attachControl(canvas, true);
    const light = new BABYLON.HemisphericLight("light1", new BABYLON.Vector3(1, 1, 0), scene);

    // Create a visual representation of AI3's heart/brain (a 3D object)
    const aiHeart = BABYLON.MeshBuilder.CreateSphere("aiHeart", { diameter: 1 }, scene);
    aiHeart.material = new BABYLON.StandardMaterial("aiMaterial", scene);
    aiHeart.material.diffuseColor = new BABYLON.Color3(0.5, 0.8, 1);

    // Animation loop
    engine.runRenderLoop(function () {
      aiHeart.rotation.y += 0.01;
      scene.render();
    });

    // Resize the engine on window resize
    window.addEventListener("resize", function () {
      engine.resize();
    });
  </script>
</body>
</html>
EOF

# Step 5: Serve the visualization locally
echo "Starting a local web server for the visualization..." | tee -a $LOG_FILE
npx http-server

echo "Babylon.js visualization environment is set up! Access it at http://localhost:8080 in your browser."
