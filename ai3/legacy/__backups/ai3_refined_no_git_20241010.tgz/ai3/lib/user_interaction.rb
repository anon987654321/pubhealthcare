class UserInteraction
  def initialize
    @user_history = {}
  end

  def log_interaction(user_id, input)
    @user_history[user_id] ||= []
    @user_history[user_id] << input
    puts "User #{user_id}: #{input}"
  end

  def get_interaction_history(user_id)
    @user_history[user_id] || []
  end
end
