# AI3

**AI3** is an advanced tool built with [Ruby](https://www.ruby-lang.org/en/) and [LangChain.rb](https://github.com/andreibondarev/langchainrb), integrating powerful language models like [ChatGPT](https://openai.com/blog/chatgpt/) directly into the Unix command line. It assists with a vast array of tasks—from personal assistance, system monitoring, and file management to application development, governance, and even designing spacecraft, new propulsion methods, and entire cities.

Leveraging the [OpenAI API](https://platform.openai.com/docs/api-reference/), AI3 provides conversational intelligence through state-of-the-art language models. It also utilizes [Weaviate](https://weaviate.io/), a vector database enabling efficient semantic searches and information retrieval. This combination delivers expertise across numerous professions, exhibiting intelligence that surpasses traditional AI systems.

## Installation

1. Clone the repository (or download the latest release).
2. Run the installer script:
   ```bash
   ./install.sh
   ```
   This will set up all necessary components and dependencies.

3. To set up the visualization UI using Babylon.js, run:
   ```bash
   ./install_viz.sh
   ```
   This will generate a new Rails app for interacting with AI3 through text, voice, and visual components.

4. To install assistants (AI tools that help with tasks), run:
   ```bash
   ./install_assistants.sh
   ```

## Usage

AI3 runs from the command line, providing assistance on numerous topics. To start interacting with AI3, run:
```bash
ai3 start
```

### Web Scraping
The `universal_scraper.rb` file uses Ferrum for headless browsing and scraping. It handles JavaScript-heavy pages, simulates user behavior, and is capable of infinite scrolling and data extraction.

### Assistants API
AI3 integrates the OpenAI Assistants API for conversational guidance. Assistants combine language models and various tools, allowing complex interactions and real-time assistance.

## Key Features

- **Advanced Language Models**: Integrates models like [ChatGPT](https://openai.com/blog/chatgpt/) for intelligent, context-aware responses.
- **Domain Expertise**: Offers specialized knowledge in fields such as science, medicine, law, and architecture.
- **Command Line Integration**: Operates seamlessly from the Unix command line, providing AI assistance without disrupting your workflow.
- **OpenAI Assistants API**: Uses the [OpenAI Assistants API](https://platform.openai.com/docs/api-reference/) for detailed, conversational guidance.
- **Vector Search**: Employs [Weaviate](https://weaviate.io/) for powerful vector-based searches and data retrieval.
- **Robust Error Handling**: Ensures smooth and reliable operation, even under complex conditions.
- **Web Browser Integration**: Enhances traditional search capabilities with tools like [Ferrum](https://github.com/rubycdp/ferrum).
- **Secure Environment**: Designed with security in mind, leveraging [OpenBSD](https://www.openbsd.org/)'s features like `pledge` and `unveil` for safe operation and data protection.

## Future Expansion: 3D Printer Interface

Once fully functional, AI3 aims to create a Ruby interface for 3D printers. A `Material Repurposing Agent` within AI3 could be responsible for creating specialized compounds as required, making it a versatile tool for innovative applications.

## License

MIT License. See the [LICENSE](./LICENSE) file for more information.

---

**AI3 streamlines your workflow, one command at a time.** 🚀
