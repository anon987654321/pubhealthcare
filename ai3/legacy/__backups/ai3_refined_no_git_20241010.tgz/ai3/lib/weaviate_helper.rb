class WeaviateHelper
  def initialize
    @client = Weaviate::Client.new(api_key: ENV["WEAVIATE_API_KEY"])
  end

  def retrieve(query)
    response = @client.query(query)
    puts "Weaviate Query Response: #{response}"
    response
  end
end
