#!/usr/bin/env zsh

cd "$BASE_DIR"

doas pkg_add llvm

# Add AI-related gems to Gemfile
bundle add langchainrb
bundle add langchainrb_rails
bundle add weaviate-ruby
bundle add replicate-ruby

bundle install

# Generate configuration for langchainrb_rails
bin/rails generate langchainrb_rails:qdrant --model=Post --llm=openai

cat <<EOF > config/initializers/langchainrb_rails.rb
require "langchainrb_rails"

Langchain::Vectorsearch::Weaviate.new(
  url: ENV["WEAVIATE_URL"],
  api_key: ENV["WEAVIATE_API_KEY"],
  index_name: "Posts",
  llm: Langchain::LLM::OpenAI.new(api_key: ENV["OPENAI_API_KEY"])
).create_default_schema
EOF

# Migrate the database to apply the new configurations
bin/rails db:migrate

# Example script to generate embeddings
bin/rails runner <<EOF
require "langchainrb"

Post.all.each do |post|
  Langchain::Vectorsearch::Weaviate.new(
    url: ENV["WEAVIATE_URL"],
    api_key: ENV["WEAVIATE_API_KEY"],
    index_name: "Items",
    llm: Langchain::LLM::OpenAI.new(api_key: ENV["OPENAI_API_KEY"])
  ).add_texts(texts: [item.to_json])
end
EOF

commit_to_git "Set up AI integrations with langchainrb, weaviate, and replicate"

