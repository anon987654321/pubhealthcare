You are analyzing the following web page: https://replicate.com/explore.
Here is the page content and a screenshot (replicate.com_explore.png).
Please identify the most important sections to scrape, considering the presence of dynamic content, pagination, and nested structures.
Focus on key sections, headings, or elements based on the content provided:
<html lang="en" class="light"><head><script src="https://cdn.rudderlabs.com/v1.1/js-integrations/GA4.min.js" async="" type="text/javascript" id="GA4_RS" data-loader="RS_JS_SDK" data-isnonnativesdk="true"></script>
  <meta charset="utf-8">
  <title>Explore –&nbsp;Replicate</title>

  
  
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  

  <link id="favicon-ico" rel="icon" href="https://d31rfu1d3w8e4q.cloudfront.net/static/favicon.c3e4e1c1e57e.ico" sizes="any">
  <link id="favicon-svg" rel="icon" href="https://d31rfu1d3w8e4q.cloudfront.net/static/favicon.78c995b286d3.svg" type="image/svg+xml">
  <link rel="mask-icon" href="https://d31rfu1d3w8e4q.cloudfront.net/static/safari-pinned-tab.4c32b8e091a9.svg" color="#FFFFFF">
  <link rel="apple-touch-icon" sizes="180x180" href="https://d31rfu1d3w8e4q.cloudfront.net/static/apple-touch-icon.1adc51db122a.png">

  
  
  <script type="module" crossorigin="" src="https://d31rfu1d3w8e4q.cloudfront.net/static/dist/index-05d2ff48.js"></script>

  <link rel="stylesheet" href="https://d31rfu1d3w8e4q.cloudfront.net/static/dist/index-8d15e76d.css">

  <link rel="alternate" type="application/rss+xml" title="Blog (RSS)" href="/blog/rss">
  <link rel="alternate" type="application/atom+xml" title="Blog (Atom)" href="/blog/atom">
  <link rel="alternate" type="application/rss+xml" title="Changelog (RSS)" href="/changelog/rss">
  <link rel="alternate" type="application/atom+xml" title="Changelog (Atom)" href="/changelog/atom">
  <link rel="alternate" type="application/rss+xml" title="Status (RSS)" href="https://replicatestatus.com/feed">

  
  <link rel="dns-prefetch" href="https://replicate.delivery">
  
  <link rel="dns-prefetch" href="https://tjzk.replicate.delivery">
  

  

  <link rel="canonical" href="https://replicate.com/explore">

  
<meta name="description" content="Discover and share open-source machine learning models from the community that you can run in the cloud using Replicate.">


  <meta name="sentry-dsn-js" content="https://3dc017e574684610bbc7fd3b5519a4e8@o255771.ingest.sentry.io/5909364">
  <meta name="rudderstack-write-key" content="2SpwbmApV5tXczEyqZrIi6PTCKN">
  <meta name="rudderstack-data-plane-url" content="https://replicateor.dataplane.rudderstack.com">
  <meta name="rudderstack-analytics-enabled" content="True">
  
  <meta name="anonymous-id" content="dd9dbee0-997b-49bc-a66b-c7a46352973a">

  
  <script nonce="">
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)').matches;

    if (prefersDarkScheme) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.add("light");
    }

  </script>
  
<style id="_goober"> @keyframes go2264125279{from{transform:scale(0) rotate(45deg);opacity:0;}to{transform:scale(1) rotate(45deg);opacity:1;}}@keyframes go3020080000{from{transform:scale(0);opacity:0;}to{transform:scale(1);opacity:1;}}@keyframes go463499852{from{transform:scale(0) rotate(90deg);opacity:0;}to{transform:scale(1) rotate(90deg);opacity:1;}}@keyframes go1268368563{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}@keyframes go1310225428{from{transform:scale(0) rotate(45deg);opacity:0;}to{transform:scale(1) rotate(45deg);opacity:1;}}@keyframes go651618207{0%{height:0;width:0;opacity:0;}40%{height:0;width:6px;opacity:1;}100%{opacity:1;height:10px;}}@keyframes go901347462{from{transform:scale(0.6);opacity:0.4;}to{transform:scale(1);opacity:1;}}.go4109123758{z-index:9999;}.go4109123758 > *{pointer-events:auto;}</style></head>



<body class="font-sans overflow-y-scroll antialiased flex min-h-screen flex-col">
  

  

  
  



  


<header id="app-header" data-stuck="false" class="bg-white/80 dark:bg-r8-gray-1 lg:sticky top-0 left-0 right-0 z-10 lg:filter backdrop-blur-md lg:mb-6">
  <div class="h-[var(--header-height)] flex items-center border-b border-transparent">
    <div class="max-w-screen-2xl w-full mx-auto px-6 lg:px-16 flex items-center justify-between gap-6">
      <div class="flex items-center gap-2 flex-shrink">
        <h1 class="flex-shrink-0 flex align-center justify-center">
          <a href="/" title="Replicate" class="text-r8-sm text-r8-gray-12 size-8 inline-flex items-center justify-center focus:bg-black focus:text-white dark:text-white logo focus:outline-black outline-offset-0 focus:outline outline-8">
            <div class="size-8 header-logo">
              <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1000 1000" class="logo" fill="currentColor" xml:space="preserve">
  <g>
    <polygon points="1000,427.6 1000,540.6 603.4,540.6 603.4,1000 477,1000 477,427.6"></polygon>
    <polygon points="1000,213.8 1000,327 364.8,327 364.8,1000 238.4,1000 238.4,213.8"></polygon>
    <polygon points="1000,0 1000,113.2 126.4,113.2 126.4,1000 0,1000 0,0"></polygon>
  </g>
</svg>

            </div>
          </a>
        </h1>

        
      </div>
      
      <div class="shrink-0">
        <div class="hidden lg:block">










<nav class="flex justify-end items-start">
  <div class="flex flex-wrap items-center gap-6">
    

    <a href="/explore" class="nav-link selected">Explore</a>

    <a href="/pricing" class="nav-link ">Pricing</a>

    <a href="https://replicate.com/docs" class="nav-link">Docs</a>

    <a href="/blog" class="nav-link ">Blog</a>

    <a href="/changelog" class="nav-link ">Changelog</a>

    

    <a href="/signin?next=/explore" class="nav-link">Sign&nbsp;in</a>

    <a href="https://replicate.com/docs" class="nav-link-primary">Get&nbsp;started</a>

    
  </div>
</nav>
</div>
        <div class="block lg:hidden"><script id="react-component-props-af64e466-950f-493e-bcab-206fe82bd9c4" type="application/json">{"isAuthenticated": false, "__flags": {"show-open-ai-api-instructions": false, "show-official-models": false, "show-connect-to-slack-button": false, "use-tiptap-text-input": false}}</script>

<div data-component="MobileMenu" data-props="react-component-props-af64e466-950f-493e-bcab-206fe82bd9c4"><button aria-expanded="false" class="r8-btn r8-btn--outlined r8-btn--primary r8-btn--sm r8-disclosure" aria-controls=":r0:"><span class="r8-btn__icon"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" viewBox="0 0 256 256"><path d="M224,128a8,8,0,0,1-8,8H40a8,8,0,0,1,0-16H216A8,8,0,0,1,224,128ZM40,72H216a8,8,0,0,0,0-16H40a8,8,0,0,0,0,16ZM216,184H40a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Z"></path></svg></span>Menu</button></div>
</div>
      </div>
    </div>
  </div>
</header>

<div class="mb-6 lg:mb-0 lg:hidden" id="js-mobile-menu"><div><div id=":r0:" hidden="" class="px-6 bg-r8-gray-1 border-b border-r8-gray-6" style="display: none;"><nav class="flex flex-col divide-y divide-r8-gray-4 py-2"><a class="block no-default no-focus px-2 py-2.5 no-underline text-r8-gray-11 hover:text-r8-gray-12 text-r8-sm" href="/explore">Explore</a><a class="block no-default no-focus px-2 py-2.5 no-underline text-r8-gray-11 hover:text-r8-gray-12 text-r8-sm" href="/pricing">Pricing</a><a class="block no-default no-focus px-2 py-2.5 no-underline text-r8-gray-11 hover:text-r8-gray-12 text-r8-sm" href="https://replicate.com/docs">Docs</a><a class="block no-default no-focus px-2 py-2.5 no-underline text-r8-gray-11 hover:text-r8-gray-12 text-r8-sm" href="/blog">Blog</a><a class="block no-default no-focus px-2 py-2.5 no-underline text-r8-gray-11 hover:text-r8-gray-12 text-r8-sm" href="/changelog">Changelog</a><a class="bg-r8-gray-12 text-r8-gray-1 px-2 py-2.5 text-center no-focus" href="/signin">Sign in</a></nav></div></div></div>

  

  

  
  

  

  <main class="layout-main flex-1">
    

    
    
<header class="md:flex gap-lh grid">
  <div class="flex-1 md:mb-8 order-1 md:order-2">
    <script id="react-component-props-e7308c25-7a91-4b85-ab0d-77d8b2f40864" type="application/json">{"__flags": {"show-open-ai-api-instructions": false, "show-official-models": false, "show-connect-to-slack-button": false, "use-tiptap-text-input": false}}</script>

<div data-component="SearchForm" data-props="react-component-props-e7308c25-7a91-4b85-ab0d-77d8b2f40864"><form method="GET" action="/search"><div class="relative"><div class="absolute left-2 top-0 bottom-0 pointer-events-none flex items-center text-r8-gray-11"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" viewBox="0 0 256 256"><path d="M229.66,218.34l-50.07-50.06a88.11,88.11,0,1,0-11.31,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Z"></path></svg></div><label for="query" class="sr-only">Search Query</label><input autocomplete="off" id="query" role="combobox" aria-autocomplete="none" aria-haspopup="listbox" aria-expanded="false" data-active-item="true" class="pl-7 border border-r8-gray-12 p-2 truncate w-full bg-white dark:bg-r8-gray-1" name="query" autocorrect="off" autocapitalize="off" spellcheck="false" maxlength="100" placeholder="Search models and collections..." value=""></div></form></div>

  </div>

  <h2 class="flex-1 h-2lh mb-lh order-1">
    Explore
  </h2>
</header>


<script id="react-component-props-81f8ea47-c751-42a5-85ed-fe5ae2180976" type="application/json">{"__flags": {"show-open-ai-api-instructions": false, "show-official-models": false, "show-connect-to-slack-button": false, "use-tiptap-text-input": false}}</script>

<div data-component="FluxBanner" data-props="react-component-props-81f8ea47-c751-42a5-85ed-fe5ae2180976"></div>



<section id="featured-models" class="mb-2lh pb-2lh border-b border-r8-gray-5">
  <h3 class="mb-lh">Featured models</h3>
  <div class="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 grid-flow-row auto-rows-max gap-2lh ">
  
  







<a class="no-default flex flex-col group border border-r8-gray-12 focus:bg-r8-gray-12" href="/black-forest-labs/flux-1.1-pro" title="black-forest-labs/flux-1.1-pro">
  <div class="h-80 group-focus:ring ring-r8-gray-12 flex-shrink-0 bg-r8-gray-3">
    

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/bd872eff-363a-4e10-8cc1-84057afa9f57/flux-1.1-cover.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy entered loading" data-ll-status="loading" src="https://tjzk.replicate.delivery/models_models_featured_image/bd872eff-363a-4e10-8cc1-84057afa9f57/flux-1.1-cover.webp">
  
</div>


  </div>
  <div class="flex-1">
    <div class="p-3 h-full flex flex-col justify-between">
      <div>
        <h4 class="inline-block group-focus:bg-r8-gray-12" translate="no">
          
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">black-forest-labs</span>
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">/</span>
          <span class="font-semibold text-r8-gray-12 group-focus:text-r8-gray-1">flux-1.1-pro</span>
        </h4>
        <p class="mt-2 text-r8-sm text-r8-gray-12 group-focus:text-r8-gray-1">
          Faster, better FLUX Pro. Text-to-image model with excellent image quality, prompt adherence, and output diversity.
        </p>
      </div>
      <div class="mt-4 flex items-center justify-between">
        <div class="text-r8-sm text-branding-red">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 131.6K runs
        </div>
        
      </div>
    </div>
  </div>
</a>

  
  







<a class="no-default flex flex-col group border border-r8-gray-12 focus:bg-r8-gray-12" href="/black-forest-labs/flux-schnell" title="black-forest-labs/flux-schnell">
  <div class="h-80 group-focus:ring ring-r8-gray-12 flex-shrink-0 bg-r8-gray-3">
    

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/67c990ba-bb67-4355-822f-2bd8c42b2f0d/flux-schnell.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy entered loading" data-ll-status="loading" src="https://tjzk.replicate.delivery/models_models_featured_image/67c990ba-bb67-4355-822f-2bd8c42b2f0d/flux-schnell.webp">
  
</div>


  </div>
  <div class="flex-1">
    <div class="p-3 h-full flex flex-col justify-between">
      <div>
        <h4 class="inline-block group-focus:bg-r8-gray-12" translate="no">
          
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">black-forest-labs</span>
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">/</span>
          <span class="font-semibold text-r8-gray-12 group-focus:text-r8-gray-1">flux-schnell</span>
        </h4>
        <p class="mt-2 text-r8-sm text-r8-gray-12 group-focus:text-r8-gray-1">
          The fastest image generation model tailored for local development and personal use
        </p>
      </div>
      <div class="mt-4 flex items-center justify-between">
        <div class="text-r8-sm text-branding-red">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 59.6M runs
        </div>
        
      </div>
    </div>
  </div>
</a>

  
  







<a class="no-default flex flex-col group border border-r8-gray-12 focus:bg-r8-gray-12" href="/black-forest-labs/flux-dev" title="black-forest-labs/flux-dev">
  <div class="h-80 group-focus:ring ring-r8-gray-12 flex-shrink-0 bg-r8-gray-3">
    

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/cb4203e5-9ece-42e7-b326-98ff3fa35c3a/Replicate_Prediction_15.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


  </div>
  <div class="flex-1">
    <div class="p-3 h-full flex flex-col justify-between">
      <div>
        <h4 class="inline-block group-focus:bg-r8-gray-12" translate="no">
          
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">black-forest-labs</span>
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">/</span>
          <span class="font-semibold text-r8-gray-12 group-focus:text-r8-gray-1">flux-dev</span>
        </h4>
        <p class="mt-2 text-r8-sm text-r8-gray-12 group-focus:text-r8-gray-1">
          A 12 billion parameter rectified flow transformer capable of generating images from text descriptions
        </p>
      </div>
      <div class="mt-4 flex items-center justify-between">
        <div class="text-r8-sm text-branding-red">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 2.2M runs
        </div>
        
      </div>
    </div>
  </div>
</a>

  
  







<a class="no-default flex flex-col group border border-r8-gray-12 focus:bg-r8-gray-12" href="/okaris/omni-zero-couples" title="okaris/omni-zero-couples">
  <div class="h-80 group-focus:ring ring-r8-gray-12 flex-shrink-0 bg-r8-gray-3">
    

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/69abe29c-832c-496a-b052-3c10d5f61a08/replicate-prediction-8_LpV9IO9.jpg" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


  </div>
  <div class="flex-1">
    <div class="p-3 h-full flex flex-col justify-between">
      <div>
        <h4 class="inline-block group-focus:bg-r8-gray-12" translate="no">
          
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">okaris</span>
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">/</span>
          <span class="font-semibold text-r8-gray-12 group-focus:text-r8-gray-1">omni-zero-couples</span>
        </h4>
        <p class="mt-2 text-r8-sm text-r8-gray-12 group-focus:text-r8-gray-1">
          Omni-Zero Couples: A diffusion pipeline for zero-shot stylized couples portrait creation.
        </p>
      </div>
      <div class="mt-4 flex items-center justify-between">
        <div class="text-r8-sm text-branding-red">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 808 runs
        </div>
        
      </div>
    </div>
  </div>
</a>

  
  







<a class="no-default flex flex-col group border border-r8-gray-12 focus:bg-r8-gray-12" href="/levelsio/counter-strike" title="levelsio/counter-strike">
  <div class="h-80 group-focus:ring ring-r8-gray-12 flex-shrink-0 bg-r8-gray-3">
    

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/423fbf1e-dac5-4416-ada4-8d7d7b14f819/replicate-prediction-_NkW53Bl.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


  </div>
  <div class="flex-1">
    <div class="p-3 h-full flex flex-col justify-between">
      <div>
        <h4 class="inline-block group-focus:bg-r8-gray-12" translate="no">
          
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">levelsio</span>
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">/</span>
          <span class="font-semibold text-r8-gray-12 group-focus:text-r8-gray-1">counter-strike</span>
        </h4>
        <p class="mt-2 text-r8-sm text-r8-gray-12 group-focus:text-r8-gray-1">
          Take pics in the style of Counter-Strike 1.6's custom map fy_resort
        </p>
      </div>
      <div class="mt-4 flex items-center justify-between">
        <div class="text-r8-sm text-branding-red">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 714 runs
        </div>
        
      </div>
    </div>
  </div>
</a>

  
  







<a class="no-default flex flex-col group border border-r8-gray-12 focus:bg-r8-gray-12" href="/meta/meta-llama-3.1-405b-instruct" title="meta/meta-llama-3.1-405b-instruct">
  <div class="h-80 group-focus:ring ring-r8-gray-12 flex-shrink-0 bg-r8-gray-3">
    

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/81ca001f-6a0a-4bef-b2f1-32466887df20/meta-logo.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


  </div>
  <div class="flex-1">
    <div class="p-3 h-full flex flex-col justify-between">
      <div>
        <h4 class="inline-block group-focus:bg-r8-gray-12" translate="no">
          
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">meta</span>
          <span class="text-r8-gray-11 group-focus:text-r8-gray-1">/</span>
          <span class="font-semibold text-r8-gray-12 group-focus:text-r8-gray-1">meta-llama-3.1-405b-instruct</span>
        </h4>
        <p class="mt-2 text-r8-sm text-r8-gray-12 group-focus:text-r8-gray-1">
          Meta's flagship 405 billion parameter language model, fine-tuned for chat completions
        </p>
      </div>
      <div class="mt-4 flex items-center justify-between">
        <div class="text-r8-sm text-branding-red">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 3M runs
        </div>
        
      </div>
    </div>
  </div>
</a>

  
</div>

</section>



<section id="collections" class="mb-2lh pb-2lh border-b border-r8-gray-5">
  <h3 class="mb-lh">I want to…</h3>
  <div class="grid grid-cols-1 xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-2 grid-flow-row auto-rows-max gap-2lh">
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/text-to-image" class="font-bold">
        Generate images
      </a>
    </h4>
    <p>
      Models that generate images from text prompts
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/bytedance/sdxl-lightning-4step">
          <span translate="no">bytedance/sdxl-lightning-4step</span>
        </a>
      </li>
      
      <li>
        <a href="/stability-ai/stable-diffusion">
          <span translate="no">stability-ai/stable-diffusion</span>
        </a>
      </li>
      
      <li>
        <a href="/stability-ai/sdxl">
          <span translate="no">stability-ai/sdxl</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/text-to-image">
          27 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/language-models" class="font-bold">
        Use a language model
      </a>
    </h4>
    <p>
      Models that can understand and generate text
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/meta/meta-llama-3-70b-instruct">
          <span translate="no">meta/meta-llama-3-70b-instruct</span>
        </a>
      </li>
      
      <li>
        <a href="/meta/meta-llama-3-8b-instruct">
          <span translate="no">meta/meta-llama-3-8b-instruct</span>
        </a>
      </li>
      
      <li>
        <a href="/meta/meta-llama-3-8b">
          <span translate="no">meta/meta-llama-3-8b</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/language-models">
          38 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/image-to-text" class="font-bold">
        Caption images
      </a>
    </h4>
    <p>
      Models that generate text from images
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/salesforce/blip">
          <span translate="no">salesforce/blip</span>
        </a>
      </li>
      
      <li>
        <a href="/andreasjansson/blip-2">
          <span translate="no">andreasjansson/blip-2</span>
        </a>
      </li>
      
      <li>
        <a href="/yorickvp/llava-13b">
          <span translate="no">yorickvp/llava-13b</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/image-to-text">
          10 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/image-editing" class="font-bold">
        Edit images
      </a>
    </h4>
    <p>
      Tools for manipulating images.
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/tencentarc/gfpgan">
          <span translate="no">tencentarc/gfpgan</span>
        </a>
      </li>
      
      <li>
        <a href="/sczhou/codeformer">
          <span translate="no">sczhou/codeformer</span>
        </a>
      </li>
      
      <li>
        <a href="/rossjillian/controlnet">
          <span translate="no">rossjillian/controlnet</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/image-editing">
          23 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/image-restoration" class="font-bold">
        Restore images
      </a>
    </h4>
    <p>
      Models that improve or restore images by deblurring, colorization, and removing noise
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/tencentarc/gfpgan">
          <span translate="no">tencentarc/gfpgan</span>
        </a>
      </li>
      
      <li>
        <a href="/sczhou/codeformer">
          <span translate="no">sczhou/codeformer</span>
        </a>
      </li>
      
      <li>
        <a href="/jingyunliang/swinir">
          <span translate="no">jingyunliang/swinir</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/image-restoration">
          17 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/super-resolution" class="font-bold">
        Upscale images
      </a>
    </h4>
    <p>
      Upscaling models that create high-quality images from low-quality images
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/nightmareai/real-esrgan">
          <span translate="no">nightmareai/real-esrgan</span>
        </a>
      </li>
      
      <li>
        <a href="/jingyunliang/swinir">
          <span translate="no">jingyunliang/swinir</span>
        </a>
      </li>
      
      <li>
        <a href="/philz1337x/clarity-upscaler">
          <span translate="no">philz1337x/clarity-upscaler</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/super-resolution">
          19 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/flux" class="font-bold">
        The FLUX.1 family of models
      </a>
    </h4>
    <p>
      The FLUX.1 family of text-to-image models from Black Forest Labs
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/black-forest-labs/flux-schnell">
          <span translate="no">black-forest-labs/flux-schnell</span>
        </a>
      </li>
      
      <li>
        <a href="/black-forest-labs/flux-pro">
          <span translate="no">black-forest-labs/flux-pro</span>
        </a>
      </li>
      
      <li>
        <a href="/black-forest-labs/flux-dev">
          <span translate="no">black-forest-labs/flux-dev</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/flux">
          1 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/embedding-models" class="font-bold">
        Get embeddings
      </a>
    </h4>
    <p>
      Models that generate embeddings from inputs
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/andreasjansson/clip-features">
          <span translate="no">andreasjansson/clip-features</span>
        </a>
      </li>
      
      <li>
        <a href="/daanelson/imagebind">
          <span translate="no">daanelson/imagebind</span>
        </a>
      </li>
      
      <li>
        <a href="/replicate/all-mpnet-base-v2">
          <span translate="no">replicate/all-mpnet-base-v2</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/embedding-models">
          5 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/text-recognition-ocr" class="font-bold">
        Extract text from images
      </a>
    </h4>
    <p>
      Optical character recognition (OCR) and text extraction
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/abiruyt/text-extract-ocr">
          <span translate="no">abiruyt/text-extract-ocr</span>
        </a>
      </li>
      
      <li>
        <a href="/cudanexus/ocr-surya">
          <span translate="no">cudanexus/ocr-surya</span>
        </a>
      </li>
      
      <li>
        <a href="/mickeybeurskens/latex-ocr">
          <span translate="no">mickeybeurskens/latex-ocr</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/text-recognition-ocr">
          2 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/transcribe-speech" class="font-bold">
        Transcribe speech
      </a>
    </h4>
    <p>
      Models that convert speech to text
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/openai/whisper">
          <span translate="no">openai/whisper</span>
        </a>
      </li>
      
      <li>
        <a href="/vaibhavs10/incredibly-fast-whisper">
          <span translate="no">vaibhavs10/incredibly-fast-whisper</span>
        </a>
      </li>
      
      <li>
        <a href="/thomasmol/whisper-diarization">
          <span translate="no">thomasmol/whisper-diarization</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/transcribe-speech">
          4 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/vision-models" class="font-bold">
        Chat with images
      </a>
    </h4>
    <p>
      Ask language models about images
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/yorickvp/llava-13b">
          <span translate="no">yorickvp/llava-13b</span>
        </a>
      </li>
      
      <li>
        <a href="/yorickvp/llava-v1.6-mistral-7b">
          <span translate="no">yorickvp/llava-v1.6-mistral-7b</span>
        </a>
      </li>
      
      <li>
        <a href="/yorickvp/llava-v1.6-vicuna-13b">
          <span translate="no">yorickvp/llava-v1.6-vicuna-13b</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/vision-models">
          15 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/utilities" class="font-bold">
        Use handy tools
      </a>
    </h4>
    <p>
      Toolbelt-type models for videos and images.
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/falcons-ai/nsfw_image_detection">
          <span translate="no">falcons-ai/nsfw_image_detection</span>
        </a>
      </li>
      
      <li>
        <a href="/cjwbw/rembg">
          <span translate="no">cjwbw/rembg</span>
        </a>
      </li>
      
      <li>
        <a href="/smoretalk/rembg-enhance">
          <span translate="no">smoretalk/rembg-enhance</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/utilities">
          15 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/use-face-to-make-images" class="font-bold">
        Use a face to make images
      </a>
    </h4>
    <p>
      Make realistic images of people instantly
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/fofr/face-to-many">
          <span translate="no">fofr/face-to-many</span>
        </a>
      </li>
      
      <li>
        <a href="/tencentarc/photomaker">
          <span translate="no">tencentarc/photomaker</span>
        </a>
      </li>
      
      <li>
        <a href="/fofr/face-to-sticker">
          <span translate="no">fofr/face-to-sticker</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/use-face-to-make-images">
          8 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/audio-generation" class="font-bold">
        Generate music
      </a>
    </h4>
    <p>
      Models to generate and modify music
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/meta/musicgen">
          <span translate="no">meta/musicgen</span>
        </a>
      </li>
      
      <li>
        <a href="/riffusion/riffusion">
          <span translate="no">riffusion/riffusion</span>
        </a>
      </li>
      
      <li>
        <a href="/allenhung1025/looptest">
          <span translate="no">allenhung1025/looptest</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/audio-generation">
          14 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/text-to-video" class="font-bold">
        Generate videos
      </a>
    </h4>
    <p>
      Models that create and edit videos
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/anotherjesse/zeroscope-v2-xl">
          <span translate="no">anotherjesse/zeroscope-v2-xl</span>
        </a>
      </li>
      
      <li>
        <a href="/lucataco/animate-diff">
          <span translate="no">lucataco/animate-diff</span>
        </a>
      </li>
      
      <li>
        <a href="/deforum/deforum_stable_diffusion">
          <span translate="no">deforum/deforum_stable_diffusion</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/text-to-video">
          22 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/text-to-speech" class="font-bold">
        Generate speech
      </a>
    </h4>
    <p>
      Convert text to speech
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/lucataco/xtts-v2">
          <span translate="no">lucataco/xtts-v2</span>
        </a>
      </li>
      
      <li>
        <a href="/zsxkib/realistic-voice-cloning">
          <span translate="no">zsxkib/realistic-voice-cloning</span>
        </a>
      </li>
      
      <li>
        <a href="/suno-ai/bark">
          <span translate="no">suno-ai/bark</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/text-to-speech">
          6 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/flux-fine-tunes" class="font-bold">
        Fine-tune Flux
      </a>
    </h4>
    <p>
      Create a fine-tuned Flux model using your own training images.
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/lucataco/hyper-flux-8step">
          <span translate="no">lucataco/hyper-flux-8step</span>
        </a>
      </li>
      
      <li>
        <a href="/fofr/flux-black-light">
          <span translate="no">fofr/flux-black-light</span>
        </a>
      </li>
      
      <li>
        <a href="/adirik/flux-cinestill">
          <span translate="no">adirik/flux-cinestill</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/flux-fine-tunes">
          591 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/3d-models" class="font-bold">
        Make 3D stuff
      </a>
    </h4>
    <p>
      Models that generate 3D objects, scenes, radiance fields, textures and multi-views.
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/cjwbw/shap-e">
          <span translate="no">cjwbw/shap-e</span>
        </a>
      </li>
      
      <li>
        <a href="/adirik/dreamgaussian">
          <span translate="no">adirik/dreamgaussian</span>
        </a>
      </li>
      
      <li>
        <a href="/jd7h/zero123plusplus">
          <span translate="no">jd7h/zero123plusplus</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/3d-models">
          9 more…
        </a>
      </li>
      
    </ul>
  </div>
  
  <div class="overflow-hidden">
    <h4 class="mb-1">
      <a href="https://replicate.com/collections/language-models-with-grammar" class="font-bold">
        Get structured data
      </a>
    </h4>
    <p>
      Language models that support grammar-based decoding as well as jsonschema constraints.
    </p>
    <ul class="mt-4 mb-1 text-sm">
      
      <li>
        <a href="/andreasjansson/codellama-7b-instruct-gguf">
          <span translate="no">andreasjansson/codellama-7b-instruct-gguf</span>
        </a>
      </li>
      
      <li>
        <a href="/andreasjansson/llama-2-13b-chat-gguf">
          <span translate="no">andreasjansson/llama-2-13b-chat-gguf</span>
        </a>
      </li>
      
      <li>
        <a href="/andreasjansson/llama-2-70b-chat-gguf">
          <span translate="no">andreasjansson/llama-2-70b-chat-gguf</span>
        </a>
      </li>
      
      
      <li>
        and
        <a href="https://replicate.com/collections/language-models-with-grammar">
          3 more…
        </a>
      </li>
      
    </ul>
  </div>
  
</div>

</section>


<section id="popular-models" class="mb-2lh pb-2lh border-b border-r8-gray-5">
  <h3 class="mb-lh">Popular models</h3>
  







<div class="grid grid-cols-1 lg:grid-cols-2 grid-flow-row auto-rows-max gap-2lh">
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/bytedance/sdxl-lightning-4step" class="no-default no-focus block focus:ring h-full" title="bytedance/sdxl-lightning-4step">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/779f3f58-c3db-4403-a01b-3ffed97a1449/out-0-1.jpg" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/bytedance/sdxl-lightning-4step" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">bytedance</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">sdxl-lightning-4step</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">SDXL-Lightning by ByteDance: a fast text-to-image model that makes high-quality images in 4 steps</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-09-16T18:44:45.812819+00:00" title="Sept. 16, 2024, 6:44 p.m.">
          2&nbsp;weeks, 4&nbsp;days ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 454.4M runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/falcons-ai/nsfw_image_detection" class="no-default no-focus block focus:ring h-full" title="falcons-ai/nsfw_image_detection">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/pbxt/JurYNQcIfISvpS6WtaOcwZXw1ifEudlLyQqiLj5N1Zq977Q3/falcon.jpg" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/falcons-ai/nsfw_image_detection" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">falcons-ai</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">nsfw_​image_​detection</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Fine-Tuned Vision Transformer (ViT) for NSFW Image Classification</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2023-11-21T14:54:02.021194+00:00" title="Nov. 21, 2023, 2:54 p.m.">
          10&nbsp;months, 1&nbsp;week ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 13.1M runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/openai/whisper" class="no-default no-focus block focus:ring h-full" title="openai/whisper">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/3b4ca926-150a-4495-94b1-a830ef093afa/whisper-diagram.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/openai/whisper" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">openai</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">whisper</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Convert speech in audio to text</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-08-23T19:27:38.927324+00:00" title="Aug. 23, 2024, 7:27 p.m.">
          1&nbsp;month, 1&nbsp;week ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 34.7M runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/salesforce/blip" class="no-default no-focus block focus:ring h-full" title="salesforce/blip">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/b59b459c-c475-414f-ba67-c424a7e6e6ca/demo.jpg" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/salesforce/blip" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">salesforce</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">blip</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Generate image captions</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2022-09-29T02:21:53.164660+00:00" title="Sept. 29, 2022, 2:21 a.m.">
          2&nbsp;years ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 102.2M runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/stability-ai/sdxl" class="no-default no-focus block focus:ring h-full" title="stability-ai/sdxl">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/9065f9e3-40da-4742-8cb8-adfa8e794c0d/sdxl_cover.jpg" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/stability-ai/sdxl" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">stability-ai</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">sdxl</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">A text-to-image generative AI model that creates beautiful images</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-05-23T23:26:26.222931+00:00" title="May 23, 2024, 11:26 p.m.">
          4&nbsp;months, 1&nbsp;week ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 66.3M runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/zf-kbot/sd-inpaint" class="no-default no-focus block focus:ring h-full" title="zf-kbot/sd-inpaint">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/pbxt/SuMA0y7PWy6fBCSezHBdamYreZboDdUAkHG9iBjHtXRP3g3mA/out-0.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/zf-kbot/sd-inpaint" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">zf-kbot</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">sd-inpaint</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Fill in masked parts of images with Stable Diffusion</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-09-06T06:38:56.909324+00:00" title="Sept. 6, 2024, 6:38 a.m.">
          4&nbsp;weeks ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 2.3M runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/xinntao/gfpgan" class="no-default no-focus block focus:ring h-full" title="xinntao/gfpgan">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/1cbbb944-ff67-404f-bb86-1b6e9ce9477e/output_1.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/xinntao/gfpgan" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">xinntao</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">gfpgan</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Practical face restoration algorithm for *old photos* or *AI-generated faces*</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2022-09-18T04:06:02.928940+00:00" title="Sept. 18, 2022, 4:06 a.m.">
          2&nbsp;years ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 15M runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/yorickvp/llava-13b" class="no-default no-focus block focus:ring h-full" title="yorickvp/llava-13b">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/454548d6-4978-4d85-bca3-d067dfc031bf/llava.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/yorickvp/llava-13b" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">yorickvp</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">llava-13b</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Visual instruction tuning towards large language and vision models with GPT-4 level capabilities</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-07-17T14:00:16.459010+00:00" title="July 17, 2024, 2 p.m.">
          2&nbsp;months, 2&nbsp;weeks ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 17.3M runs
        </span>
      </div>
    </div>
  </div>
  
</div>

</section>


<section id="latest-models">
  <h3 class="mb-lh">Latest models</h3>
  

<nav class="pagination flex lining-nums tabular-nums my-lh" aria-label="pagination">

  
  <div class="flex-1"></div>
  

  
  <span class="flex-auto text-center">
    Page 1
  </span>
  

  
  <div class="flex-1 text-right">
    <a href="?latest_models_page=2#latest-models" rel="next" class="no-underline">
      <span class="mr-2 underline hidden sm:inline">Next page</span>
      <span class="inline-block h-4"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" direction="ltr" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span>
    </a>
  </div>
  

</nav>



  







<div class="grid grid-cols-1 lg:grid-cols-2 grid-flow-row auto-rows-max gap-2lh">
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/brandnexus/cold_stoic" class="no-default no-focus block focus:ring h-full" title="brandnexus/cold_stoic">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/JHZt2vjsjG5SIFhctxvfeq6zn1D6f8fuvZ5asJftwIeGVZ24E/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/brandnexus/cold_stoic" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">brandnexus</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">cold_​stoic</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-04T22:16:49.500924+00:00" title="Oct. 4, 2024, 10:16 p.m.">
          15&nbsp;seconds ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 17 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/justmalhar/meta-llama-3.2-11b-vision" class="no-default no-focus block focus:ring h-full" title="justmalhar/meta-llama-3.2-11b-vision">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/pbxt/LjoVjObT8FOT8vQFsPfOoxr17sRMDQMihn2C4bzMec3BkDHo/IMG_3310.jpeg" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/justmalhar/meta-llama-3.2-11b-vision" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">justmalhar</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">meta-llama-3.2-11b-vision</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">This is a test version, more updates coming</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-04T18:55:57.099122+00:00" title="Oct. 4, 2024, 6:55 p.m.">
          3&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 21 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/nelsonjchen/op-replay-clipper" class="no-default no-focus block focus:ring h-full" title="nelsonjchen/op-replay-clipper">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_cover_image/3b4afaf7-3881-43ae-b9f2-3a6fceee8b21/cog-replay-clip.gif" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/nelsonjchen/op-replay-clipper" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">nelsonjchen</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">op-replay-clipper</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">GPU accelerated replay renderer / video data clipper for comma.ai connect's openpilot route data. SEE README.</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-04T17:37:35.564051+00:00" title="Oct. 4, 2024, 5:37 p.m.">
          4&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 2.8K runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/villesau/whisper-timestamped" class="no-default no-focus block focus:ring h-full" title="villesau/whisper-timestamped">
        

<div class="h-full w-full overflow-hidden bg-r8-gray-a4 flex items-center justify-center">
  
  <div aria-hidden="" class="w-8 h-8 text-r8-gray-8">
    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1000 1000" class="logo" fill="currentColor" xml:space="preserve">
  <g>
    <polygon points="1000,427.6 1000,540.6 603.4,540.6 603.4,1000 477,1000 477,427.6"></polygon>
    <polygon points="1000,213.8 1000,327 364.8,327 364.8,1000 238.4,1000 238.4,213.8"></polygon>
    <polygon points="1000,0 1000,113.2 126.4,113.2 126.4,1000 0,1000 0,0"></polygon>
  </g>
</svg>

  </div>
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/villesau/whisper-timestamped" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">villesau</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">whisper-timestamped</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Transcribes audio using Whisper Large V3 with precise word-level timestamps and confidence scores.</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-04T13:22:18.307122+00:00" title="Oct. 4, 2024, 1:22 p.m.">
          8&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 50 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/bern6666/venere01" class="no-default no-focus block focus:ring h-full" title="bern6666/venere01">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/i051ncxHPG7YJJDdS0SpS70jLGDwclGsnafHUB6lMQ0qouxJA/out-3.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/bern6666/venere01" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">bern6666</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">venere01</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-04T13:12:44.795147+00:00" title="Oct. 4, 2024, 1:12 p.m.">
          9&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 26 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/dashed/whisperx-subtitles-replicate" class="no-default no-focus block focus:ring h-full" title="dashed/whisperx-subtitles-replicate">
        

<div class="h-full w-full overflow-hidden bg-r8-gray-a4 flex items-center justify-center">
  
  <div aria-hidden="" class="w-8 h-8 text-r8-gray-8">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <circle cx="12" cy="12" r="10"></circle>
  <polygon points="10 8 16 12 10 16 10 8"></polygon>
</svg>

  </div>
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/dashed/whisperx-subtitles-replicate" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">dashed</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">whisperx-subtitles-replicate</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Generates subtitles from audio using whisperX (faster-whisper-large-v3)</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-04T10:58:22.243183+00:00" title="Oct. 4, 2024, 10:58 a.m.">
          11&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 90 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/advoworks/lokidog" class="no-default no-focus block focus:ring h-full" title="advoworks/lokidog">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/QsauXoi2sq7ECZamf8PzdGt5q0SFaXc1Tf8bk0dx8l7lseymA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/advoworks/lokidog" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">advoworks</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">lokidog</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-04T04:48:34.679560+00:00" title="Oct. 4, 2024, 4:48 a.m.">
          17&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 210 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/aymankarim/syriandesign" class="no-default no-focus block focus:ring h-full" title="aymankarim/syriandesign">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/Pvaka50Cc8bFAVZ7CLlLXqHRiV9xmIT2JEfxtQj4aLrVBnxJA/out-0.jpg" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/aymankarim/syriandesign" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">aymankarim</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">syriandesign</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-03T23:43:53.656528+00:00" title="Oct. 3, 2024, 11:43 p.m.">
          22&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 8 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/aymankarim/syriancourtyard" class="no-default no-focus block focus:ring h-full" title="aymankarim/syriancourtyard">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/fQ5xiEerzNjvl0uRHdfxI70szRNrjUCjjlE407JZiaPWDcGnA/out-0.jpg" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/aymankarim/syriancourtyard" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">aymankarim</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">syriancourtyard</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-03T23:40:21.272952+00:00" title="Oct. 3, 2024, 11:40 p.m.">
          22&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 10 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/aymankarim/vibhaus2" class="no-default no-focus block focus:ring h-full" title="aymankarim/vibhaus2">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/94EetTTNpxxhYqmLpIF1Pl5pgLeg0APHfIqfcvxb4Ns7H4MOB/out-0.jpg" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/aymankarim/vibhaus2" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">aymankarim</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">vibhaus2</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-03T23:38:41.586631+00:00" title="Oct. 3, 2024, 11:38 p.m.">
          22&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 8 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/henn0124/watch-swtch" class="no-default no-focus block focus:ring h-full" title="henn0124/watch-swtch">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/GUREVJNZVtoee0qeo8nOoY88NGrKRRS4Fry82UkeIqBEztMOB/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/henn0124/watch-swtch" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">henn0124</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">watch-swtch</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-03T20:44:04.960230+00:00" title="Oct. 3, 2024, 8:44 p.m.">
          1&nbsp;day, 1&nbsp;hour ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 17 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/aonori3/symbia_covid_20figs" class="no-default no-focus block focus:ring h-full" title="aonori3/symbia_covid_20figs">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/Sutt3IvtkjKpGxcpLJSR6S31J77jqZFsVI7zBYzdvBsbzy4E/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/aonori3/symbia_covid_20figs" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">aonori3</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">symbia_​covid_​20figs</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-03T20:39:01.742929+00:00" title="Oct. 3, 2024, 8:39 p.m.">
          1&nbsp;day, 1&nbsp;hour ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 6 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/tiziisa93/ai-sableluxe" class="no-default no-focus block focus:ring h-full" title="tiziisa93/ai-sableluxe">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/1Jqm0WLfTyRvAad5K3zd5oNyOEHx0WpQkrqaKrtBjyVE1lxJA/out-0.jpg" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/tiziisa93/ai-sableluxe" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">tiziisa93</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">ai-sableluxe</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-03T20:37:38.243889+00:00" title="Oct. 3, 2024, 8:37 p.m.">
          1&nbsp;day, 1&nbsp;hour ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 30 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/henn0124/af1-l" class="no-default no-focus block focus:ring h-full" title="henn0124/af1-l">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/jCaeHDcafooBZEs4RKQHtTVNAfAsJVmrxBOVIqsaYtBNWOGnA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/henn0124/af1-l" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">henn0124</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">af1-l</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Imagine your own shoe style</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-03T15:50:51.433285+00:00" title="Oct. 3, 2024, 3:50 p.m.">
          1&nbsp;day, 6&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 31 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/mrodartistry/photoofaemproduct" class="no-default no-focus block focus:ring h-full" title="mrodartistry/photoofaemproduct">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/ZVYfaGBsQATpJKeNgXs92EZfO7cmCa6ALo66BfMBgDLSPcMOB/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/mrodartistry/photoofaemproduct" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">mrodartistry</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">photoofaemproduct</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-03T15:43:46.310513+00:00" title="Oct. 3, 2024, 3:43 p.m.">
          1&nbsp;day, 6&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 28 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/roblig7/luciana" class="no-default no-focus block focus:ring h-full" title="roblig7/luciana">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/qI7VyY5PTPpwFJaatIADRNSZEnrXcjXdBzxwoQnpalgJlx4E/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/roblig7/luciana" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">roblig7</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">luciana</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-03T15:03:42.162683+00:00" title="Oct. 3, 2024, 3:03 p.m.">
          1&nbsp;day, 7&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 28 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/black-forest-labs/flux-1.1-pro" class="no-default no-focus block focus:ring h-full" title="black-forest-labs/flux-1.1-pro">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/bd872eff-363a-4e10-8cc1-84057afa9f57/flux-1.1-cover.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/black-forest-labs/flux-1.1-pro" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">black-forest-labs</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">flux-1.1-pro</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Faster, better FLUX Pro. Text-to-image model with excellent image quality, prompt adherence, and output diversity.</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-03T13:45:13.547780+00:00" title="Oct. 3, 2024, 1:45 p.m.">
          1&nbsp;day, 8&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 131.6K runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/hsandaver/gothmodel" class="no-default no-focus block focus:ring h-full" title="hsandaver/gothmodel">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/XwlHbw9G33LdLdrw0onRYoPKszvjjNnRojkgRV0h4DVS8w4E/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/hsandaver/gothmodel" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">hsandaver</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">gothmodel</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-03T12:06:27.606282+00:00" title="Oct. 3, 2024, 12:06 p.m.">
          1&nbsp;day, 10&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 11 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/jimothyjohn/phi3-vision-instruct" class="no-default no-focus block focus:ring h-full" title="jimothyjohn/phi3-vision-instruct">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_cover_image/554397db-769f-4d42-96a2-0fd98867aa66/output_6.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/jimothyjohn/phi3-vision-instruct" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">jimothyjohn</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">phi3-vision-instruct</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">A soon-to-be accelerated endpoint for multi-modal inference.</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T21:03:07.303557+00:00" title="Oct. 2, 2024, 9:03 p.m.">
          2&nbsp;days, 1&nbsp;hour ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 126 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/fofr/flux-dev-day" class="no-default no-focus block focus:ring h-full" title="fofr/flux-dev-day">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/w2lmYgfp1hT1P6Qgdfxev7ClrZeWz50vnxqgG1bZAXdnISLOB/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/fofr/flux-dev-day" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">fofr</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">flux-dev-day</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T18:51:58.315391+00:00" title="Oct. 2, 2024, 6:51 p.m.">
          2&nbsp;days, 3&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 48 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/skvilla/n1nd0l" class="no-default no-focus block focus:ring h-full" title="skvilla/n1nd0l">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/x5EO222vFXbnI1lpjol7Mmil9ivdA6SxunktBYanvdRJLu4E/out-1.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/skvilla/n1nd0l" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">skvilla</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">n1nd0l</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T18:00:15.161119+00:00" title="Oct. 2, 2024, 6 p.m.">
          2&nbsp;days, 4&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 87 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/razvanmtn/old-books-model" class="no-default no-focus block focus:ring h-full" title="razvanmtn/old-books-model">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/7l5h2PaftOQcHqyXkCUjJ0ZhMP7c8qvhOWlZ9837yHwDHZxJA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/razvanmtn/old-books-model" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">razvanmtn</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">old-books-model</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Generates images of old books</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T16:01:54.985845+00:00" title="Oct. 2, 2024, 4:01 p.m.">
          2&nbsp;days, 6&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 4 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/tiziisa93/ai-bluerose" class="no-default no-focus block focus:ring h-full" title="tiziisa93/ai-bluerose">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/q4GgAkUeDGw4f0XfrLMENiO34Qejo2j64dIgIDSTakaBjRLOB/out-0.jpg" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/tiziisa93/ai-bluerose" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">tiziisa93</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">ai-bluerose</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T15:28:06.730728+00:00" title="Oct. 2, 2024, 3:28 p.m.">
          2&nbsp;days, 6&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 70 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/its-magick/merlin-bob" class="no-default no-focus block focus:ring h-full" title="its-magick/merlin-bob">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/03dpvftq2QX5fU5HGgOhUhkUmp5EED1k4DnQPeTWJbfiPeVcC/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/its-magick/merlin-bob" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">its-magick</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">merlin-bob</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T12:31:17.925368+00:00" title="Oct. 2, 2024, 12:31 p.m.">
          2&nbsp;days, 9&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 11 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/surajop06/suraj06" class="no-default no-focus block focus:ring h-full" title="surajop06/suraj06">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/Fu7GbU6CWRrOIlbgFHKznV8Wegn4CXcLvs0ewVYqeXwyYWFnA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/surajop06/suraj06" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">surajop06</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">suraj06</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T08:06:50.137341+00:00" title="Oct. 2, 2024, 8:06 a.m.">
          2&nbsp;days, 14&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 16 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/lucataco/flux.1-controlnet-lineart-promeai" class="no-default no-focus block focus:ring h-full" title="lucataco/flux.1-controlnet-lineart-promeai">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/88kSGaX5Qi6dABAPhXJCVqzUTtIrBPrqNO2fI5esR88rfVFnA/output.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/lucataco/flux.1-controlnet-lineart-promeai" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">lucataco</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">flux.1-controlnet-lineart-promeai</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Controlnet trained on black-forest-labs/FLUX.1-dev with lineart condition</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T07:56:30.662899+00:00" title="Oct. 2, 2024, 7:56 a.m.">
          2&nbsp;days, 14&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 53 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/justmalhar/flux-thumbnails-v2" class="no-default no-focus block focus:ring h-full" title="justmalhar/flux-thumbnails-v2">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_cover_image/56f97d6e-2dc1-498d-908f-1b8267f76cc4/IMG_8003.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/justmalhar/flux-thumbnails-v2" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">justmalhar</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">flux-thumbnails-v2</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T06:39:09.266659+00:00" title="Oct. 2, 2024, 6:39 a.m.">
          2&nbsp;days, 15&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 58 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/cybermerlo/cga_pc_game" class="no-default no-focus block focus:ring h-full" title="cybermerlo/cga_pc_game">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/HHNLFxzj87Z4ORqfJHGFZ7Q8zoKWvKFUJ4EuXvZoZH6o4UxJA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/cybermerlo/cga_pc_game" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">cybermerlo</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">cga_​pc_​game</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Generate images in a CGA PC Game style</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T06:15:01.425639+00:00" title="Oct. 2, 2024, 6:15 a.m.">
          2&nbsp;days, 16&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 19 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/black-forest-labs/flux-schnell" class="no-default no-focus block focus:ring h-full" title="black-forest-labs/flux-schnell">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/67c990ba-bb67-4355-822f-2bd8c42b2f0d/flux-schnell.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/black-forest-labs/flux-schnell" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">black-forest-labs</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">flux-schnell</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">The fastest image generation model tailored for local development and personal use</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T01:37:54.199755+00:00" title="Oct. 2, 2024, 1:37 a.m.">
          2&nbsp;days, 20&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 59.6M runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/black-forest-labs/flux-dev" class="no-default no-focus block focus:ring h-full" title="black-forest-labs/flux-dev">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_featured_image/cb4203e5-9ece-42e7-b326-98ff3fa35c3a/Replicate_Prediction_15.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/black-forest-labs/flux-dev" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">black-forest-labs</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">flux-dev</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">A 12 billion parameter rectified flow transformer capable of generating images from text descriptions</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-02T01:36:05.962718+00:00" title="Oct. 2, 2024, 1:36 a.m.">
          2&nbsp;days, 20&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 2.2M runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/giojsus12/gioa" class="no-default no-focus block focus:ring h-full" title="giojsus12/gioa">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/4cv6aXb0JHJpARoH73NJLzwwy6lMKHFM1PSsUCS0llp6no4E/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/giojsus12/gioa" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">giojsus12</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">gioa</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T21:43:59.146916+00:00" title="Oct. 1, 2024, 9:43 p.m.">
          3&nbsp;days ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 41 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/fofr/flux-messy-desktop" class="no-default no-focus block focus:ring h-full" title="fofr/flux-messy-desktop">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/svkE7EqbA4JwGdgvff1uVNRk6Rn93sd3tIRCaLCQqRI6shiTA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/fofr/flux-messy-desktop" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">fofr</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">flux-messy-desktop</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T21:07:30.418139+00:00" title="Oct. 1, 2024, 9:07 p.m.">
          3&nbsp;days, 1&nbsp;hour ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 117 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/steppae/steppae" class="no-default no-focus block focus:ring h-full" title="steppae/steppae">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/w8eAzvkrIIx4C6g7rG39Od0F19sia8ikymDfis0ybvyN0qiTA/out-0.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/steppae/steppae" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">steppae</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">steppae</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T20:13:49.829247+00:00" title="Oct. 1, 2024, 8:13 p.m.">
          3&nbsp;days, 2&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 85 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/henn0124/jonah" class="no-default no-focus block focus:ring h-full" title="henn0124/jonah">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/YHizfD8Ddw0PFCdEPbfDgBpG2gW4yggcdhOckXCGhIU65fEnA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/henn0124/jonah" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">henn0124</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">jonah</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T19:20:32.286479+00:00" title="Oct. 1, 2024, 7:20 p.m.">
          3&nbsp;days, 2&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 14 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/henn0124/industrial-design-sketch" class="no-default no-focus block focus:ring h-full" title="henn0124/industrial-design-sketch">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/mBuvMDRM4e3NSqOWl7Nf4MJdEiEGEyyPunRI5UfZ3FSi18EnA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/henn0124/industrial-design-sketch" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">henn0124</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">industrial-design-sketch</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Create industrial design concept sketches</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T16:49:15.509300+00:00" title="Oct. 1, 2024, 4:49 p.m.">
          3&nbsp;days, 5&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 88 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/smoretalk/flamel-inpainting" class="no-default no-focus block focus:ring h-full" title="smoretalk/flamel-inpainting">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_cover_image/33551fc7-6b51-422e-8614-f0185296ec33/inpainting-thumbnail.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/smoretalk/flamel-inpainting" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">smoretalk</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">flamel-inpainting</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Add or change what you want on your image</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T16:44:20.150238+00:00" title="Oct. 1, 2024, 4:44 p.m.">
          3&nbsp;days, 5&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 2.5K runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/waterfrog/water-lily" class="no-default no-focus block focus:ring h-full" title="waterfrog/water-lily">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/zMUSYSlUbubSJhyPCyHdzlOTivaRSdN3JXzSfN7fFcQDKciTA/out-3.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/waterfrog/water-lily" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">waterfrog</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">water-lily</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T14:56:49.615679+00:00" title="Oct. 1, 2024, 2:56 p.m.">
          3&nbsp;days, 7&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 4 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/heywowyou/heywowflux" class="no-default no-focus block focus:ring h-full" title="heywowyou/heywowflux">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/xtBWBMjoPGI4N1fEK1jJy8heulgfOQ2uVaMUlwQkDjkzivCnA/out-2.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/heywowyou/heywowflux" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">heywowyou</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">heywowflux</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T14:24:03.998291+00:00" title="Oct. 1, 2024, 2:24 p.m.">
          3&nbsp;days, 7&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 344 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/astronautdavid1/mad31-flux-lora" class="no-default no-focus block focus:ring h-full" title="astronautdavid1/mad31-flux-lora">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/sIXH4K2uTibvJFcQvwnpth4t5RY18z3F6sSf4WdwPJCVtNxJA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/astronautdavid1/mad31-flux-lora" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">astronautdavid1</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">mad31-flux-lora</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T07:00:44.879125+00:00" title="Oct. 1, 2024, 7 a.m.">
          3&nbsp;days, 15&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 15 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/zeke/lowly-worm" class="no-default no-focus block focus:ring h-full" title="zeke/lowly-worm">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/tyTrOGZB2XJmPtH8eIZkkQXvAbkrf2yax4SJraa2KKAZJTiTA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/zeke/lowly-worm" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">zeke</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">lowly-worm</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Richard Scarry's lowly worm</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T04:37:58.838338+00:00" title="Oct. 1, 2024, 4:37 a.m.">
          3&nbsp;days, 17&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 8 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/laggingdingo/aria-women" class="no-default no-focus block focus:ring h-full" title="laggingdingo/aria-women">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/pE7f4ZpOenpNzUDkl5xLyG5Sm9haAmC8y3NmmSnafaG1LlEnA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/laggingdingo/aria-women" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">laggingdingo</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">aria-women</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">A model for young black women, 19-24 y/o. Use BKWO.</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T04:10:13.917862+00:00" title="Oct. 1, 2024, 4:10 a.m.">
          3&nbsp;days, 18&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 30 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/jfals82/berno" class="no-default no-focus block focus:ring h-full" title="jfals82/berno">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/pbxt/qbtifsapGoxrdSeJQ9QiZvAfz1kPIm2p3giwe70rTCuN8CJOB/out-0.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/jfals82/berno" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">jfals82</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">berno</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T02:05:38.561636+00:00" title="Oct. 1, 2024, 2:05 a.m.">
          3&nbsp;days, 20&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 4 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/jfals82/nathan" class="no-default no-focus block focus:ring h-full" title="jfals82/nathan">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/pbxt/wtoCke2zesogep0uDw1Gi3e5WZMsueohiq9fJAvyyB5hiHk4E/out-0.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/jfals82/nathan" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">jfals82</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">nathan</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T01:37:21.277236+00:00" title="Oct. 1, 2024, 1:37 a.m.">
          3&nbsp;days, 20&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 8 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/chenxwh/depthcrafter" class="no-default no-focus block focus:ring h-full" title="chenxwh/depthcrafter">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_cover_image/9e41aeb3-c198-4dee-9ed9-c77a3761aaae/replicate-prediction-vyef_UBc69v0.gif" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/chenxwh/depthcrafter" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">chenxwh</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">depthcrafter</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Generating Consistent Long Depth Sequences for Open-world Videos</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-10-01T00:15:16.888543+00:00" title="Oct. 1, 2024, 12:15 a.m.">
          3&nbsp;days, 22&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 18 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/miike-ai/flux-sprites" class="no-default no-focus block focus:ring h-full" title="miike-ai/flux-sprites">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/VPaxqOrgmWLYI1rNwGo5jrA2ynFk5GWj3Jfrdq8ShvPhiPxJA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/miike-ai/flux-sprites" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">miike-ai</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">flux-sprites</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Sprite sheets made easy.  Give it a whirl!</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-09-30T23:49:57.635397+00:00" title="Sept. 30, 2024, 11:49 p.m.">
          3&nbsp;days, 22&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 65 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/senatoracadia/pulp" class="no-default no-focus block focus:ring h-full" title="senatoracadia/pulp">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/z774dBnEHYL2FhAg8KQMYmRUJVNstV5VQfF79F8beSInWIjTA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/senatoracadia/pulp" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">senatoracadia</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">pulp</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">This model creates images in the style of pulp novels and magazines from the mid 20th century.  Tough</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-09-30T21:08:16.385063+00:00" title="Sept. 30, 2024, 9:08 p.m.">
          4&nbsp;days, 1&nbsp;hour ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 10 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/jonbesga/naigore" class="no-default no-focus block focus:ring h-full" title="jonbesga/naigore">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/1pS5t346JGoRHtfo4SzaN8yBe788Kam1vZVw7ukAvM8JyLiTA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/jonbesga/naigore" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">jonbesga</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">naigore</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">A fine-tuned FLUX.1 model with Nagore's art</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-09-30T20:28:13.885078+00:00" title="Sept. 30, 2024, 8:28 p.m.">
          4&nbsp;days, 1&nbsp;hour ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 3 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/smoretalk/flamel-eraser" class="no-default no-focus block focus:ring h-full" title="smoretalk/flamel-eraser">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://tjzk.replicate.delivery/models_models_cover_image/16323a5e-8d41-4a35-ab7c-bff86917f7b5/eraser-thumbnail.png" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/smoretalk/flamel-eraser" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">smoretalk</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">flamel-eraser</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1">Erase what you don't want on your image</p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-09-30T18:29:40.903068+00:00" title="Sept. 30, 2024, 6:29 p.m.">
          4&nbsp;days, 3&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 91 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/ailingangel/menger1" class="no-default no-focus block focus:ring h-full" title="ailingangel/menger1">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/JAcfM02MRYXPBCOzacT8caedDxa53r4Lnj2QOt0HIsu5OHiTA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/ailingangel/menger1" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">ailingangel</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">menger1</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-09-30T15:09:05.802961+00:00" title="Sept. 30, 2024, 3:09 p.m.">
          4&nbsp;days, 7&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 13 runs
        </span>
      </div>
    </div>
  </div>
  
  <div class="flex gap-x-lh">
    <div class="flex-none w-36 h-32">
      <a href="/nariman-mamutov-ew/harold-flux-model" class="no-default no-focus block focus:ring h-full" title="nariman-mamutov-ew/harold-flux-model">
        

<div class=" h-full w-full overflow-hidden">
  
  <img data-src="https://replicate.delivery/yhqm/Dx4C4mAzsG4mCZNUf3yx6grHA95LxjLAdmdpvopXsXcn2CxJA/out-0.webp" alt="" role="presentation" class="object-cover object-center w-full h-full lazy">
  
</div>


      </a>
    </div>
    <div class="flex-grow overflow-hidden">
      <div class="flex flex-wrap gap-x-3 overflow-hidden">
        <h4 class="mb-1 overflow-hidden overflow-ellipsis" translate="no">
          
          <a href="/nariman-mamutov-ew/harold-flux-model" class="no-default focus:ring group focus:text-r8-gray-1">
            <span class="text-r8-gray-11 group-focus:text-r8-gray-1">nariman-mamutov-ew</span><span class="text-r8-gray-11 group-focus:text-r8-gray-1 px-1">/</span><span class="text-r8-gray-12 group-focus:text-r8-gray-1">harold-flux-model</span>
          </a>
        </h4>

        
      </div>

      <p class="mb-1"></p>

      <div class="text-r8-gray-11 text-sm">
        Updated <time datetime="2024-09-30T13:31:33.962142+00:00" title="Sept. 30, 2024, 1:31 p.m.">
          4&nbsp;days, 8&nbsp;hours ago
        </time>
        <span class="float-right">
          
<svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
  <path fill="currentColor" fill-rule="evenodd" d="M20.322.75a10.75 10.75 0 00-7.373 2.926l-1.304 1.23A23.743 23.743 0 0010.103 6.5H5.066a1.75 1.75 0 00-1.5.85l-2.71 4.514a.75.75 0 00.49 1.12l4.571.963c.039.049.082.096.129.14L8.04 15.96l1.872 1.994c.044.047.091.09.14.129l.963 4.572a.75.75 0 001.12.488l4.514-2.709a1.75 1.75 0 00.85-1.5v-5.038a23.741 23.741 0 001.596-1.542l1.228-1.304a10.75 10.75 0 002.925-7.374V2.499A1.75 1.75 0 0021.498.75h-1.177zM16 15.112c-.333.248-.672.487-1.018.718l-3.393 2.262.678 3.223 3.612-2.167a.25.25 0 00.121-.214v-3.822zm-10.092-2.7L8.17 9.017c.23-.346.47-.685.717-1.017H5.066a.25.25 0 00-.214.121l-2.167 3.612 3.223.679zm8.07-7.644a9.25 9.25 0 016.344-2.518h1.177a.25.25 0 01.25.25v1.176a9.25 9.25 0 01-2.517 6.346l-1.228 1.303a22.248 22.248 0 01-3.854 3.257l-3.288 2.192-1.743-1.858a.764.764 0 00-.034-.034l-1.859-1.744 2.193-3.29a22.248 22.248 0 013.255-3.851l1.304-1.23zM17.5 8a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zm-11 13c.9-.9.9-2.6 0-3.5-.9-.9-2.6-.9-3.5 0-1.209 1.209-1.445 3.901-1.49 4.743a.232.232 0 00.247.247c.842-.045 3.534-.281 4.743-1.49z"></path>
</svg>
 28 runs
        </span>
      </div>
    </div>
  </div>
  
</div>

  

<nav class="pagination flex lining-nums tabular-nums my-lh" aria-label="pagination">

  
  <div class="flex-1"></div>
  

  
  <span class="flex-auto text-center">
    Page 1
  </span>
  

  
  <div class="flex-1 text-right">
    <a href="?latest_models_page=2#latest-models" rel="next" class="no-underline">
      <span class="mr-2 underline hidden sm:inline">Next page</span>
      <span class="inline-block h-4"><svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" direction="ltr" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span>
    </a>
  </div>
  

</nav>



</section>



    
    
  </main>

  
  <div class="layout-footer">
    

<footer class="flex flex-col md:flex-row gap-lh justify-between">
  <div class="flex items-center gap-3 overflow-hidden">
    <a class="flex-shrink-0" href="/">Replicate</a>
    <div class="flex-1">
      <iframe src="https://replicatestatus.com/badge" id="status-badge" height="30" width="100%" frameborder="0" scrolling="no"></iframe>
    </div>
  </div>
  <div class="flex items-center flex-wrap gap-05lh">
    
    <a href="/home">Home</a>
    <a href="/about">About</a>
    <a href="/guides">Guides</a>
    <a href="/newsletter">Newsletter</a>
    <a href="/terms">Terms</a>
    <a href="/privacy">Privacy</a>
    <a href="https://replicatestatus.com/">Status</a>
    <a href="https://github.com/replicate" translate="no">GitHub</a>
    <a href="https://x.com/replicate" translate="no">X</a>
    <a href="https://discord.gg/replicate" translate="no">Discord</a>
    <a href="/support">Support</a>
    <script id="react-component-props-7d80a792-d305-4e5e-ae1f-a089e201232c" type="application/json">{"theme": "", "__flags": {"show-open-ai-api-instructions": false, "show-official-models": false, "show-connect-to-slack-button": false, "use-tiptap-text-input": false}}</script>

<div data-component="DarkModeToggle" data-props="react-component-props-7d80a792-d305-4e5e-ae1f-a089e201232c"></div>

  </div>
</footer>

  </div>
  

  

  <script nonce="">
    window.VIDEOJS_NO_DYNAMIC_STYLE = true;

  </script>

  <script nonce="">
    const header = document.getElementById("app-header");

    function monitorHeaderStickiness() {
      if (header) {
        header.setAttribute("data-stuck", window.scrollY > 0);
      }
    }

    monitorHeaderStickiness();

    document.addEventListener("scroll", (event) => {
      monitorHeaderStickiness();
    });

  </script>
  




</body></html>
