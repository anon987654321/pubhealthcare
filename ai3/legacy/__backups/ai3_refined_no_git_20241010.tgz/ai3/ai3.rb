#!/usr/bin/env ruby
# AI3 main script

require_relative "lib/command_handler"
require_relative "lib/context_manager"
require_relative "lib/enhanced_model_architecture"
require_relative "lib/error_handling"
require_relative "lib/explainable_ai_tools"
require_relative "lib/feedback_manager"
require_relative "lib/filesystem_tool"
require_relative "lib/interactive_session"
require_relative "lib/memory_manager"
require_relative "lib/prompt_manager"
require_relative "lib/query_cache"
require_relative "lib/rag_system"
require_relative "lib/rate_limit_tracker"
require_relative "lib/real_time_processing"
require_relative "lib/schema_manager"
require_relative "lib/universal_scraper"
require_relative "lib/user_interaction"
require_relative "lib/weaviate_helper"
require 'langchain'
require 'concurrent'

class AI3
  def initialize
    puts "AI^3 Initialized"
    @interactive_session = InteractiveSession.new(RAGSystem.new(WeaviateHelper.new), MemoryManager.new)
  end

  # Start the interactive CLI session
  def start
    puts "Starting AI^3 Interactive CLI..."
    @interactive_session.start
  end
end

AI3.new.start if __FILE__ == $0
