#!/usr/bin/env ruby

require 'fileutils'
require 'open-uri'
require_relative 'universal_scraper'

# -- CONFIGURATION --

OUTPUT_DIR = '__docs'
FileUtils.mkdir_p(OUTPUT_DIR)

# -- URLS --

web_urls = {
  'rails_edge_guides' => 'https://edgeguides.rubyonrails.org/',
  'turbo' => 'https://turbo.hotwired.dev/handbook/introduction',
  'stimulus' => 'https://stimulus.hotwired.dev/handbook',
  'stimulus_reflex' => 'https://docs.stimulusreflex.com/',
  'stimulus_components' => 'https://stimulus-components.com/docs/',
  'stimulus_reflex_patterns' => 'https://stimulusreflexpatterns.com/patterns/',
  'devise' => 'https://github.com/heartcombo/devise/wiki/How-Tos',
  'replicate_docs' => 'https://replicate.com/docs',
  'replicate_explore' => 'https://replicate.com/explore',
  'nngroup' => 'https://nngroup.com/articles/',
  'solidus_guides' => 'https://guides.solidus.io/',
  'solidus_integrations' => 'https://solidus.io/integrations',
  'solidus_global_commerce' => 'https://solidus.io/use-cases/global-commerce',
  'solidus_subscriptions' => 'https://solidus.io/use-cases/subscriptions',
  'solidus_marketplaces' => 'https://solidus.io/use-cases/marketplaces',
  'openbsd_handbook' => 'https://www.openbsd.org/handbook.html'
}

repo_urls = {
  'langchainrb' => 'https://github.com/patterns-ai-core/langchainrb/archive/refs/heads/main.zip',
  'langchainrb_rails' => 'https://github.com/patterns-ai-core/langchainrb_rails/archive/refs/heads/main.zip',
  'ruby_openai' => 'https://github.com/alexrudall/ruby-openai/archive/refs/heads/main.zip',
  'replicate_ruby' => 'https://github.com/dreamingtulpa/replicate-ruby/archive/refs/heads/main.zip',
  'devise_guests' => 'https://github.com/cbeer/devise-guests/archive/refs/heads/master.zip',
  'solidus_starter_frontend' => 'https://github.com/solidusio/solidus_starter_frontend/archive/refs/heads/main.zip',
  'ferrum' => 'https://github.com/rubycdp/ferrum/archive/refs/heads/main.zip',
  'faker' => 'https://github.com/faker-ruby/faker/archive/refs/heads/main.zip',
  'weaviate_ruby' => 'https://github.com/patterns-ai-core/weaviate-ruby/archive/refs/heads/main.zip'
}

# -- SCRAPING DOCUMENTATION --

scraper = UniversalScraper.new(
  log_level: Logger::INFO,
  api_key: ENV['OPENAI_API_KEY'],
  humanize: true,
  validate: true,
  validation_min_length: 100,
  batch_size: 5
)

web_urls.each_slice(scraper.options[:batch_size]).with_index do |url_batch, index|
  scraper.logger.info("Processing batch #{index + 1} of #{(web_urls.size / scraper.options[:batch_size].to_f).ceil}")
  url_batch.each do |_name, url|
    scraper.scrape(url)
  end
end

# -- DOWNLOADING GITHUB REPOS --

def download_repo(repo_name, repo_url, logger)
  zip_file_path = "#{repo_name}.zip"
  if File.exist?(zip_file_path)
    logger.info("Skipping #{repo_name}, already downloaded.")
    return
  end

  begin
    URI.open(repo_url) { |uri_data| File.write(zip_file_path, uri_data.read) }
    logger.info("Downloaded repo: #{repo_name}")
  rescue StandardError => e
    logger.error("Error downloading #{repo_name}: #{e.message}")
  end
end

repo_urls.each do |name, url|
  download_repo(name, url, scraper.logger)
end

scraper.logger.info('Documentation scraper finished successfully')

