class CommandHandler
  def initialize
    @commands = {}
    register_default_commands
  end

  # Registers the default commands for file browsing and modification
  def register_default_commands
    register_command(:browse_directory) { |path| FilesystemTool.browse_directory(path) }
    register_command(:modify_file) { |path, content| FilesystemTool.modify_file(path, content) }
  end

  # Registers a custom command with a block of logic
  def register_command(name, &block)
    @commands[name.to_sym] = block
  end

  # Executes a registered command
  def execute_command(name, *args)
    command = @commands[name.to_sym]
    if command
      command.call(*args)
    else
      log_error("Command '#{name}' not found")
    end
  rescue StandardError => e
    log_error("Error executing command '#{name}': #{e.message}")
  end

  private

  # Logs an error message
  def log_error(message)
    puts "[ERROR] #{message}"
  end
end
