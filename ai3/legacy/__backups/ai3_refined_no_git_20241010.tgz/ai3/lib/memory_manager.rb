
# encoding: utf-8
# Memory manager for short-term and long-term memory handling

class MemoryManager
