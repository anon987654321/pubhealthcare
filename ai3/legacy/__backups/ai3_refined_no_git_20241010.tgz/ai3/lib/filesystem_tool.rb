class FilesystemTool
  CHUNK_SIZE = 4096  # Define the size for file chunking

  def self.browse_directory(path)
    if Dir.exist?(path)
      Dir.entries(path).each { |entry| puts entry }
    else
      puts "[ERROR]: Directory not found"
    end
  end

  def self.modify_file(path, content)
    if File.exist?(path)
      File.write(path, content)
      puts "File modified successfully."
    else
      puts "[ERROR]: File not found"
    end
  end

  # Reads a file and yields content in chunks
  def self.read_file_in_chunks(path)
    return "[ERROR]: File not found" unless File.exist?(path)

    File.open(path, 'r') do |file|
      file.each_chunk(CHUNK_SIZE) { |chunk| yield(chunk) }
    end
  end
end
