# encoding: utf-8

require 'langchain'

class WeaviateIntegration
