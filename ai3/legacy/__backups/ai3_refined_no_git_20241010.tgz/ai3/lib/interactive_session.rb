class InteractiveSession
  def initialize(rag_system, memory_manager)
    @rag_system = rag_system
    @memory_manager = memory_manager
  end

  # Start the interactive session
  def start
    puts "AI^3 Interactive Session started. Type 'exit' to quit."
    loop do
      print "> "
      input = gets.chomp
      break if input == 'exit'

      process_input(input)
    end
  end

  # Process user input and send it to RAG system
  def process_input(input)
    response = @rag_system.handle_query(input)
    puts "AI^3 Response: #{response}"
  end
end
