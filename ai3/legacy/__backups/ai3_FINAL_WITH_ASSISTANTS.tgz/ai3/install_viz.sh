
#!/usr/bin/env zsh
# AI3 Visualization Setup using Babylon.js

# Define directory
PROJECT_DIR="${HOME}/ai3_viz"
LOG_FILE="${PROJECT_DIR}/ai3_viz_install.log"

# Install Node.js and npm
echo "Installing Node.js and npm..."
pkg_add node

# Create project folder and initialize npm project
mkdir -p $PROJECT_DIR
cd $PROJECT_DIR

echo "Initializing npm project..." | tee -a $LOG_FILE
npm init -y

# Install Babylon.js
echo "Installing Babylon.js and dependencies..." | tee -a $LOG_FILE
npm install babylonjs

# Create the visualization script using Babylon.js
echo "Creating Babylon.js visualization script..." | tee -a $LOG_FILE
cat << 'EOF' > $PROJECT_DIR/index.html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI3 Brain Visualization</title>
  <script src="node_modules/babylonjs/babylon.js"></script>
  <style>
    body { margin: 0; overflow: hidden; }
    canvas { width: 100vw; height: 100vh; display: block; }
  </style>
</head>
<body>
  <canvas id="renderCanvas"></canvas>

  <script>
    // Babylon.js setup
    const canvas = document.getElementById('renderCanvas');
    const engine = new BABYLON.Engine(canvas, true);
    const scene = new BABYLON.Scene(engine);

    // Create a camera and a light
    const camera = new BABYLON.ArcRotateCamera("Camera", Math.PI / 2, Math.PI / 2, 2, BABYLON.Vector3.Zero(), scene);
    camera.attachControl(canvas, true);
    const light = new BABYLON.HemisphericLight("light1", new BABYLON.Vector3(1, 1, 0), scene);

    // AI3 Brain Visualization
    const aiBrain = BABYLON.MeshBuilder.CreateSphere("aiBrain", { diameter: 1 }, scene);
    aiBrain.material = new BABYLON.StandardMaterial("aiMaterial", scene);
    aiBrain.material.diffuseColor = new BABYLON.Color3(0.5, 0.8, 1);

    engine.runRenderLoop(() => {
      aiBrain.rotation.y += 0.01;
      scene.render();
    });

    window.addEventListener("resize", () => engine.resize());
  </script>
</body>
</html>
EOF

# Serve the visualization locally
echo "Starting a local web server..." | tee -a $LOG_FILE
npx http-server

echo "Babylon.js visualization is set up! Access it at http://localhost:8080"
