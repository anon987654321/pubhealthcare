You are analyzing the following web page: https://edgeguides.rubyonrails.org/.
Here is the page content and a screenshot (edgeguides.rubyonrails.org_.png).
Please identify the most important sections to scrape, considering the presence of dynamic content, pagination, and nested structures.
Focus on key sections, headings, or elements based on the content provided:
<html dir="ltr" lang="en"><head><style type="text/css">.turbo-progress-bar {
  position: fixed;
  display: block;
  top: 0;
  left: 0;
  height: 3px;
  background: #0076ff;
  z-index: 2147483647;
  transition:
    width 300ms ease-out,
    opacity 150ms 150ms ease-in;
  transform: translate3d(0, 0, 0);
}
</style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ruby on Rails Guides</title>
  <link rel="stylesheet" type="text/css" href="stylesheets/style-9e7329e5b4c46ecb619db14d43a6724d.css" data-turbo-track="reload">
  <link rel="stylesheet" type="text/css" href="stylesheets/print-a4d2686c548e59657450d04dc27f7787.css" media="print">
  <link rel="stylesheet" type="text/css" href="stylesheets/highlight-a0d2133dd0073968b2d33b1f1360a2a3.css" data-turbo-track="reload">

  <link rel="icon" href="images/favicon.ico" sizes="any">

  <link rel="apple-touch-icon" href="images/icon.png">

  <script src="javascripts/@hotwired--turbo-764f59c7edbeb902a9068c0340dd274e.js" data-turbo-track="reload"></script>
  <script src="javascripts/clipboard-8b7aed6f069f0cf58eeae353cd2f898b.js" data-turbo-track="reload"></script>
  <script src="javascripts/guides-be644dbd164a32c619aa8f714fc0b4bf.js" data-turbo-track="reload"></script>

  <meta property="og:title" content="Ruby on Rails Guides">
  <meta name="description" content="Ruby on Rails Guides">
  <meta property="og:description" content="Ruby on Rails Guides">
  <meta property="og:locale" content="en_US">
  <meta property="og:site_name" content="Ruby on Rails Guides">
  <meta property="og:image" content="https://avatars.githubusercontent.com/u/4223">
  <meta property="og:type" content="website">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic:wght@100..900&amp;display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@100..900&amp;family=Noto+Sans+Arabic:wght@100..900&amp;display=swap" rel="stylesheet">

  <meta name="theme-color" content="#C81418">
</head>

<body class="guide">
  <nav id="topNav" aria-label="Secondary">
    <div class="wrapper">
      <strong class="more-info-label">More at <a href="https://rubyonrails.org/">rubyonrails.org:</a> </strong>
      <span class="red-button more-info-button">
        More Ruby on Rails
      </span>
      <ul class="more-info-links s-hidden">
        <li class="more-info"><a href="https://rubyonrails.org/blog">Blog</a></li>
        <li class="more-info"><a href="https://guides.rubyonrails.org/">Guides</a></li>
        <li class="more-info"><a href="https://api.rubyonrails.org/">API</a></li>
        <li class="more-info"><a href="https://discuss.rubyonrails.org/">Forum</a></li>
        <li class="more-info"><a href="https://github.com/rails/rails">Contribute on GitHub</a></li>
      </ul>
    </div>
  </nav>
  <header id="page_header">
    <div class="wrapper clearfix">
      <nav id="feature_nav">
        <div class="header-logo">
          <a href="index.html" title="Return to the Guides Home for Edge Guides">Guides</a>
          <span id="version_switcher">
            Version:
            <select class="guides-version">
              <option value="https://edgeguides.rubyonrails.org/" selected="">Edge</option>
                <option value="https://guides.rubyonrails.org/v7.2/">7.2</option>
                <option value="https://guides.rubyonrails.org/v7.1/">7.1</option>
                <option value="https://guides.rubyonrails.org/v7.0/">7.0</option>
                <option value="https://guides.rubyonrails.org/v6.1/">6.1</option>
                <option value="https://guides.rubyonrails.org/v6.0/">6.0</option>
                <option value="https://guides.rubyonrails.org/v5.2/">5.2</option>
                <option value="https://guides.rubyonrails.org/v5.1/">5.1</option>
                <option value="https://guides.rubyonrails.org/v5.0/">5.0</option>
                <option value="https://guides.rubyonrails.org/v4.2/">4.2</option>
                <option value="https://guides.rubyonrails.org/v4.1/">4.1</option>
                <option value="https://guides.rubyonrails.org/v4.0/">4.0</option>
                <option value="https://guides.rubyonrails.org/v3.2/">3.2</option>
                <option value="https://guides.rubyonrails.org/v3.1/">3.1</option>
                <option value="https://guides.rubyonrails.org/v3.0/">3.0</option>
                <option value="https://guides.rubyonrails.org/v2.3/">2.3</option>
            </select>
          </span>
        </div>
        <ul class="nav">
          <li><a class="nav-item" id="home_nav" href="https://rubyonrails.org/">Home</a></li>
          <li class="guides-index guides-index-large">
            <a href="index.html" id="guidesMenu" class="guides-index-item nav-item">Guides Index</a>
            <div id="guides" class="clearfix" style="display: none;">
              <hr>
              <dl class="guides-section-container">
                  <div class="guides-section">
                    <dt>Start Here</dt>
                    <dd><a href="getting_started.html">Getting Started with Rails</a></dd>
                  </div>
                  <div class="guides-section">
                    <dt>Models</dt>
                    <dd><a href="active_record_basics.html">Active Record Basics</a></dd>
                    <dd><a href="active_record_migrations.html">Active Record Migrations</a></dd>
                    <dd><a href="active_record_validations.html">Active Record Validations</a></dd>
                    <dd><a href="active_record_callbacks.html">Active Record Callbacks</a></dd>
                    <dd><a href="association_basics.html">Active Record Associations</a></dd>
                    <dd><a href="active_record_querying.html">Active Record Query Interface</a></dd>
                    <dd><a href="active_model_basics.html">Active Model Basics</a></dd>
                  </div>
                  <div class="guides-section">
                    <dt>Views</dt>
                    <dd><a href="action_view_overview.html">Action View Overview</a></dd>
                    <dd><a href="layouts_and_rendering.html">Layouts and Rendering in Rails</a></dd>
                    <dd><a href="action_view_helpers.html">Action View Helpers</a></dd>
                    <dd><a href="form_helpers.html">Action View Form Helpers</a></dd>
                  </div>
                  <div class="guides-section">
                    <dt>Controllers</dt>
                    <dd><a href="action_controller_overview.html">Action Controller Overview</a></dd>
                    <dd><a href="routing.html">Rails Routing from the Outside In</a></dd>
                  </div>
                  <div class="guides-section">
                    <dt>Other Components</dt>
                    <dd><a href="active_support_core_extensions.html">Active Support Core Extensions</a></dd>
                    <dd><a href="action_mailer_basics.html">Action Mailer Basics</a></dd>
                    <dd><a href="action_mailbox_basics.html">Action Mailbox Basics</a></dd>
                    <dd><a href="action_text_overview.html">Action Text Overview</a></dd>
                    <dd><a href="active_job_basics.html">Active Job Basics</a></dd>
                    <dd><a href="active_storage_overview.html">Active Storage Overview</a></dd>
                    <dd><a href="action_cable_overview.html">Action Cable Overview</a></dd>
                  </div>
                  <div class="guides-section">
                    <dt>Digging Deeper</dt>
                    <dd><a href="i18n.html">Rails Internationalization (I18n) API</a></dd>
                    <dd><a href="testing.html">Testing Rails Applications</a></dd>
                    <dd><a href="security.html">Securing Rails Applications</a></dd>
                    <dd><a href="error_reporting.html">Error Reporting in Rails Applications</a></dd>
                    <dd><a href="debugging_rails_applications.html">Debugging Rails Applications</a></dd>
                    <dd><a href="configuring.html">Configuring Rails Applications</a></dd>
                    <dd><a href="command_line.html">The Rails Command Line</a></dd>
                    <dd><a href="asset_pipeline.html">The Asset Pipeline</a></dd>
                    <dd><a href="working_with_javascript_in_rails.html">Working with JavaScript in Rails</a></dd>
                    <dd><a href="autoloading_and_reloading_constants.html">Autoloading and Reloading</a></dd>
                    <dd><a href="caching_with_rails.html">Caching with Rails: An Overview</a></dd>
                    <dd><a href="api_app.html">Using Rails for API-only Applications</a></dd>
                    <dd><a href="tuning_performance_for_deployment.html">Tuning Performance for Deployment</a></dd>
                  </div>
                  <div class="guides-section">
                    <dt>Advanced Active Record</dt>
                    <dd><a href="active_record_multiple_databases.html">Multiple Databases</a></dd>
                    <dd><a href="active_record_composite_primary_keys.html">Composite Primary Keys</a></dd>
                  </div>
                  <div class="guides-section">
                    <dt>Extending Rails</dt>
                    <dd><a href="rails_on_rack.html">Rails on Rack</a></dd>
                    <dd><a href="generators.html">Creating and Customizing Rails Generators &amp; Templates</a></dd>
                  </div>
                  <div class="guides-section">
                    <dt>Contributing</dt>
                    <dd><a href="contributing_to_ruby_on_rails.html">Contributing to Ruby on Rails</a></dd>
                    <dd><a href="api_documentation_guidelines.html">API Documentation Guidelines</a></dd>
                    <dd><a href="ruby_on_rails_guides_guidelines.html">Guides Guidelines</a></dd>
                    <dd><a href="development_dependencies_install.html">Installing Rails Core Development Dependencies</a></dd>
                  </div>
                  <div class="guides-section">
                    <dt>Policies</dt>
                    <dd><a href="maintenance_policy.html">Maintenance Policy</a></dd>
                  </div>
                  <div class="guides-section">
                    <dt>Release Notes</dt>
                    <dd><a href="upgrading_ruby_on_rails.html">Upgrading Ruby on Rails</a></dd>
                    <dd><a href="7_2_release_notes.html">Version 7.2 - August 2024</a></dd>
                    <dd><a href="7_1_release_notes.html">Version 7.1 - October 2023</a></dd>
                    <dd><a href="7_0_release_notes.html">Version 7.0 - December 2021</a></dd>
                    <dd><a href="6_1_release_notes.html">Version 6.1 - December 2020</a></dd>
                    <dd><a href="6_0_release_notes.html">Version 6.0 - August 2019</a></dd>
                    <dd><a href="5_2_release_notes.html">Version 5.2 - April 2018</a></dd>
                    <dd><a href="5_1_release_notes.html">Version 5.1 - April 2017</a></dd>
                    <dd><a href="5_0_release_notes.html">Version 5.0 - June 2016</a></dd>
                    <dd><a href="4_2_release_notes.html">Version 4.2 - December 2014</a></dd>
                    <dd><a href="4_1_release_notes.html">Version 4.1 - April 2014</a></dd>
                    <dd><a href="4_0_release_notes.html">Version 4.0 - June 2013</a></dd>
                    <dd><a href="3_2_release_notes.html">Version 3.2 - January 2012</a></dd>
                    <dd><a href="3_1_release_notes.html">Version 3.1 - August 2011</a></dd>
                    <dd><a href="3_0_release_notes.html">Version 3.0 - August 2010</a></dd>
                    <dd><a href="2_3_release_notes.html">Version 2.3 - March 2009</a></dd>
                    <dd><a href="2_2_release_notes.html">Version 2.2 - November 2008</a></dd>
                  </div>
              </dl>
            </div>
          </li>
          <li><a class="nav-item" href="contributing_to_ruby_on_rails.html">Contribute</a></li>
          <li class="guides-index guides-index-small">
            <select class="guides-index-item nav-item">
              <option value="index.html">Guides Index</option>
                <optgroup label="Start Here">
                    <option value="getting_started.html">Getting Started with Rails</option>
                </optgroup>
                <optgroup label="Models">
                    <option value="active_record_basics.html">Active Record Basics</option>
                    <option value="active_record_migrations.html">Active Record Migrations</option>
                    <option value="active_record_validations.html">Active Record Validations</option>
                    <option value="active_record_callbacks.html">Active Record Callbacks</option>
                    <option value="association_basics.html">Active Record Associations</option>
                    <option value="active_record_querying.html">Active Record Query Interface</option>
                    <option value="active_model_basics.html">Active Model Basics</option>
                </optgroup>
                <optgroup label="Views">
                    <option value="action_view_overview.html">Action View Overview</option>
                    <option value="layouts_and_rendering.html">Layouts and Rendering in Rails</option>
                    <option value="action_view_helpers.html">Action View Helpers</option>
                    <option value="form_helpers.html">Action View Form Helpers</option>
                </optgroup>
                <optgroup label="Controllers">
                    <option value="action_controller_overview.html">Action Controller Overview</option>
                    <option value="routing.html">Rails Routing from the Outside In</option>
                </optgroup>
                <optgroup label="Other Components">
                    <option value="active_support_core_extensions.html">Active Support Core Extensions</option>
                    <option value="action_mailer_basics.html">Action Mailer Basics</option>
                    <option value="action_mailbox_basics.html">Action Mailbox Basics</option>
                    <option value="action_text_overview.html">Action Text Overview</option>
                    <option value="active_job_basics.html">Active Job Basics</option>
                    <option value="active_storage_overview.html">Active Storage Overview</option>
                    <option value="action_cable_overview.html">Action Cable Overview</option>
                </optgroup>
                <optgroup label="Digging Deeper">
                    <option value="i18n.html">Rails Internationalization (I18n) API</option>
                    <option value="testing.html">Testing Rails Applications</option>
                    <option value="security.html">Securing Rails Applications</option>
                    <option value="error_reporting.html">Error Reporting in Rails Applications</option>
                    <option value="debugging_rails_applications.html">Debugging Rails Applications</option>
                    <option value="configuring.html">Configuring Rails Applications</option>
                    <option value="command_line.html">The Rails Command Line</option>
                    <option value="asset_pipeline.html">The Asset Pipeline</option>
                    <option value="working_with_javascript_in_rails.html">Working with JavaScript in Rails</option>
                    <option value="autoloading_and_reloading_constants.html">Autoloading and Reloading</option>
                    <option value="caching_with_rails.html">Caching with Rails: An Overview</option>
                    <option value="api_app.html">Using Rails for API-only Applications</option>
                    <option value="tuning_performance_for_deployment.html">Tuning Performance for Deployment</option>
                </optgroup>
                <optgroup label="Advanced Active Record">
                    <option value="active_record_multiple_databases.html">Multiple Databases</option>
                    <option value="active_record_composite_primary_keys.html">Composite Primary Keys</option>
                </optgroup>
                <optgroup label="Extending Rails">
                    <option value="rails_on_rack.html">Rails on Rack</option>
                    <option value="generators.html">Creating and Customizing Rails Generators &amp; Templates</option>
                </optgroup>
                <optgroup label="Contributing">
                    <option value="contributing_to_ruby_on_rails.html">Contributing to Ruby on Rails</option>
                    <option value="api_documentation_guidelines.html">API Documentation Guidelines</option>
                    <option value="ruby_on_rails_guides_guidelines.html">Guides Guidelines</option>
                    <option value="development_dependencies_install.html">Installing Rails Core Development Dependencies</option>
                </optgroup>
                <optgroup label="Policies">
                    <option value="maintenance_policy.html">Maintenance Policy</option>
                </optgroup>
                <optgroup label="Release Notes">
                    <option value="upgrading_ruby_on_rails.html">Upgrading Ruby on Rails</option>
                    <option value="7_2_release_notes.html">Version 7.2 - August 2024</option>
                    <option value="7_1_release_notes.html">Version 7.1 - October 2023</option>
                    <option value="7_0_release_notes.html">Version 7.0 - December 2021</option>
                    <option value="6_1_release_notes.html">Version 6.1 - December 2020</option>
                    <option value="6_0_release_notes.html">Version 6.0 - August 2019</option>
                    <option value="5_2_release_notes.html">Version 5.2 - April 2018</option>
                    <option value="5_1_release_notes.html">Version 5.1 - April 2017</option>
                    <option value="5_0_release_notes.html">Version 5.0 - June 2016</option>
                    <option value="4_2_release_notes.html">Version 4.2 - December 2014</option>
                    <option value="4_1_release_notes.html">Version 4.1 - April 2014</option>
                    <option value="4_0_release_notes.html">Version 4.0 - June 2013</option>
                    <option value="3_2_release_notes.html">Version 3.2 - January 2012</option>
                    <option value="3_1_release_notes.html">Version 3.1 - August 2011</option>
                    <option value="3_0_release_notes.html">Version 3.0 - August 2010</option>
                    <option value="2_3_release_notes.html">Version 2.3 - March 2009</option>
                    <option value="2_2_release_notes.html">Version 2.2 - November 2008</option>
                </optgroup>
            </select>
          </li>
      </ul>
      </nav>
    </div>
  </header>
  <hr class="hide">

  <section id="feature">
    <div class="wrapper">
      <h1>Ruby on Rails Guides (8ac9954)</h1>

<p>
  These are <b>Edge Guides</b>, based on <a href="https://github.com/rails/rails/tree/8ac995453a2a2efd789810a90319e6bb6f0e2aea">main@8ac9954</a>.
</p>
<p>
  If you are looking for the ones for the stable version, please check
  <a href="https://guides.rubyonrails.org">https://guides.rubyonrails.org</a> instead.
</p>
<p>
The guides for earlier releases:
<a href="https://guides.rubyonrails.org/v7.1/" data-turbo="false">Rails 7.1</a>,
<a href="https://guides.rubyonrails.org/v7.0/" data-turbo="false">Rails 7.0</a>,
<a href="https://guides.rubyonrails.org/v6.1/" data-turbo="false">Rails 6.1</a>,
<a href="https://guides.rubyonrails.org/v6.0/" data-turbo="false">Rails 6.0</a>,
<a href="https://guides.rubyonrails.org/v5.2/" data-turbo="false">Rails 5.2</a>,
<a href="https://guides.rubyonrails.org/v5.1/" data-turbo="false">Rails 5.1</a>,
<a href="https://guides.rubyonrails.org/v5.0/" data-turbo="false">Rails 5.0</a>,
<a href="https://guides.rubyonrails.org/v4.2/" data-turbo="false">Rails 4.2</a>,
<a href="https://guides.rubyonrails.org/v4.1/" data-turbo="false">Rails 4.1</a>,
<a href="https://guides.rubyonrails.org/v4.0/" data-turbo="false">Rails 4.0</a>,
<a href="https://guides.rubyonrails.org/v3.2/" data-turbo="false">Rails 3.2</a>,
<a href="https://guides.rubyonrails.org/v3.1/" data-turbo="false">Rails 3.1</a>,
<a href="https://guides.rubyonrails.org/v3.0/" data-turbo="false">Rails 3.0</a>, and
<a href="https://guides.rubyonrails.org/v2.3/" data-turbo="false">Rails 2.3</a>.
</p>



      <nav id="subCol" aria-label="Chapter" class="guide-index">
  <dl>
    <dt></dt>
    <dd class="interstitial work-in-progress">Guides marked with this icon are currently being worked on and will not be available in the Guides Index menu. While still useful, they may contain incomplete information and even errors. You can help by reviewing them and posting your comments and corrections.</dd>
  </dl>
</nav>


      <hr>
    </div>
  </section>

  <main id="container">
    <div class="wrapper">
      <div id="mainCol">
        


  <h2>Start Here</h2>
  <dl class="guide-index-list">
      <dt><a href="getting_started.html">Getting Started with Rails</a></dt><dd>
        <p>Everything you need to know to install Rails and create your first application.</p>
</dd>  </dl>
  <h2>Models</h2>
  <dl class="guide-index-list">
      <dt><a href="active_record_basics.html">Active Record Basics</a></dt><dd>
        <p>Active Record allows your models to interact with the application's database. This guide will get you started with Active Record models and persistence to the database.
</p>
</dd>      <dt><a href="active_record_migrations.html">Active Record Migrations</a></dt><dd>
        <p>Migrations are a feature of Active Record that allows you to evolve your database schema over time. Rather than write schema modifications in pure SQL, migrations allow you to use a Ruby DSL to describe changes to your tables.
</p>
</dd>      <dt><a href="active_record_validations.html">Active Record Validations</a></dt><dd>
        <p>Validations are used to ensure that only valid data is saved into your database. This guide teaches you how to validate the state of objects before they go into the database, using Active Record's validations feature.
</p>
</dd>      <dt><a href="active_record_callbacks.html">Active Record Callbacks</a></dt><dd>
        <p>Callbacks make it possible to write code that will run whenever an object is created, updated, destroyed, etc. This guide teaches you how to hook into this object life cycle of Active Record objects.
</p>
</dd>      <dt><a href="association_basics.html">Active Record Associations</a></dt><dd>
        <p>In Active Record, an association is a connection between two Active Record models. This guide covers all the associations provided by Active Record.
</p>
</dd>      <dt><a href="active_record_querying.html">Active Record Query Interface</a></dt><dd>
        <p>Instead of using raw SQL to find database records, Active Record provides better ways to carry out the same operations. This guide covers different ways to retrieve data from the database using Active Record.
</p>
</dd>      <dt><a href="active_model_basics.html">Active Model Basics</a></dt><dd>
        <p>Active Model allows you to create plain Ruby objects that integrate with Action Pack, but don't need Active Record for database persistence. Active Model also helps build custom ORMs for use outside of the Rails framework. This guide provides you with all you need to get started using Active Model classes.
</p>
</dd>  </dl>
  <h2>Views</h2>
  <dl class="guide-index-list">
      <dt><a href="action_view_overview.html">Action View Overview</a></dt><dd>
        <p>Action View is responsible for generating the HTML for web responses. This guide provides an introduction to Action View.
</p>
</dd>      <dt><a href="layouts_and_rendering.html">Layouts and Rendering in Rails</a></dt><dd>
        <p>This guide covers the basic layout features of Action Controller and Action View, including rendering and redirecting, using content_for blocks, and working with partials.</p>
</dd>      <dt><a href="action_view_helpers.html">Action View Helpers</a></dt><dd>
        <p>Action View has helpers for handling everything from formatting dates and linking to images, to sanitizing and localizing content. This guide introduces a few of the more common Action View helpers.
</p>
</dd>      <dt><a href="form_helpers.html">Action View Form Helpers</a></dt><dd>
        <p>HTML forms can quickly become tedious to write and maintain because of the need to handle form control naming and its numerous attributes. Rails does away with this complexity by providing view helpers for generating form markup.
</p>
</dd>  </dl>
  <h2>Controllers</h2>
  <dl class="guide-index-list">
      <dt><a href="action_controller_overview.html">Action Controller Overview</a></dt><dd>
        <p>Action Controllers are the core of a web request in Rails. This guide covers how controllers work and how they fit into the request cycle of your application. It includes sessions, filters, cookies, data streaming, and dealing with exceptions raised by a request, among other topics.
</p>
</dd>      <dt><a href="routing.html">Rails Routing from the Outside In</a></dt><dd>
        <p>The Rails router recognizes URLs and dispatches them to a controller's action. This guide covers the user-facing features of Rails routing. If you want to understand how to use routing in your own Rails applications, start here.
</p>
</dd>  </dl>
  <h2>Other Components</h2>
  <dl class="guide-index-list">
      <dt><a href="active_support_core_extensions.html">Active Support Core Extensions</a></dt><dd>
        <p>Active Support provides Ruby language extensions and utilities. It enriches the Ruby language for the development of Rails applications, and for the development of Ruby on Rails itself.
</p>
</dd>      <dt><a href="action_mailer_basics.html">Action Mailer Basics</a></dt><dd>
        <p>This guide provides you with all you need to get started in sending emails from your application, and many internals of Action Mailer.
</p>
</dd>      <dt><a href="action_mailbox_basics.html">Action Mailbox Basics</a></dt><dd>
        <p>This guide describes how to use Action Mailbox to receive emails.</p>
</dd>      <dt><a href="action_text_overview.html">Action Text Overview</a></dt><dd>
        <p>This guide describes how to use Action Text to handle rich text content.</p>
</dd>      <dt><a href="active_job_basics.html">Active Job Basics</a></dt><dd>
        <p>Active Job is a framework for declaring background jobs and making them run on a variety of queuing backends. This guide provides you with all you need to get started creating, enqueuing, and executing background jobs.
</p>
</dd>      <dt><a href="active_storage_overview.html">Active Storage Overview</a></dt><dd>
        <p>Active Storage facilitates uploading files to a cloud storage service, transforming uploads and extracting metadata. This guide covers how to attach files to your Active Record models.
</p>
</dd>      <dt><a href="action_cable_overview.html">Action Cable Overview</a></dt><dd>
        <p>Action Cable integrates WebSockets with the rest of your Rails application. It allows for real-time features to be written in Ruby in the same style and form as the rest of your Rails application. This guide explains how Action Cable works, and how to use WebSockets to create real-time features.
</p>
</dd>  </dl>
  <h2>Digging Deeper</h2>
  <dl class="guide-index-list">
      <dt><a href="i18n.html">Rails Internationalization (I18n) API</a></dt><dd>
        <p>This guide covers how to add internationalization to your applications. Your application will be able to translate content to different languages, change pluralization rules, use correct date formats for each country, and so on.</p>
</dd>      <dt><a href="testing.html">Testing Rails Applications</a></dt><dd>
        <p>This is a rather comprehensive guide to the various testing facilities in Rails. It covers everything from 'What is a test?' to Integration Testing. Enjoy.</p>
</dd>      <dt><a href="security.html">Securing Rails Applications</a></dt><dd>
        <p>This guide describes common security problems in web applications and how to avoid them with Rails.</p>
</dd>      <dt><a href="error_reporting.html">Error Reporting in Rails Applications</a></dt><dd>
        <p>This guide introduces ways to manage exceptions that occur in Ruby on Rails applications.</p>
</dd>      <dt><a href="debugging_rails_applications.html">Debugging Rails Applications</a></dt><dd>
        <p>This guide describes how to debug Rails applications. It covers the different ways of achieving this and how to understand what is happening "behind the scenes" of your code.</p>
</dd>      <dt><a href="configuring.html">Configuring Rails Applications</a></dt><dd>
        <p>This guide covers the basic configuration settings for a Rails application.</p>
</dd>      <dt><a href="command_line.html">The Rails Command Line</a></dt><dd>
        <p>There are a few commands that are absolutely critical to your everyday usage of Rails. This guide covers the command line tools provided by Rails.
</p>
</dd>      <dt><a href="asset_pipeline.html">The Asset Pipeline</a></dt><dd>
        <p>The asset pipeline provides a framework to concatenate and minify or compress JavaScript, CSS and image assets. It also adds the ability to write these assets in other languages and pre-processors such as CoffeeScript, Sass, and ERB.
</p>
</dd>      <dt><a href="working_with_javascript_in_rails.html">Working with JavaScript in Rails</a></dt><dd>
        <p>This guide explains how to use import maps or jsbundling-rails to include JavaScript in Rails applications, and covers the basics of working with Turbo in Rails.
</p>
</dd>      <dt><a href="initialization.html">The Rails Initialization Process</a></dt><dd class="interstitial work-in-progress">Work in progress</dd><dd>
        <p>This guide explains the internals of the initialization process in Rails. It is an extremely in-depth guide and recommended for advanced Rails developers.
</p>
</dd>      <dt><a href="autoloading_and_reloading_constants.html">Autoloading and Reloading</a></dt><dd>
        <p>This guide documents how autoloading and reloading constants work.</p>
</dd>      <dt><a href="caching_with_rails.html">Caching with Rails: An Overview</a></dt><dd>
        <p>This guide is an introduction to speeding up your Rails application with caching.</p>
</dd>      <dt><a href="active_support_instrumentation.html">Active Support Instrumentation</a></dt><dd class="interstitial work-in-progress">Work in progress</dd><dd>
        <p>This guide explains how to use the instrumentation API inside of Active Support to measure events inside of Rails and other Ruby code.</p>
</dd>      <dt><a href="api_app.html">Using Rails for API-only Applications</a></dt><dd>
        <p>This guide explains how to effectively use Rails to develop a JSON API application.</p>
</dd>      <dt><a href="tuning_performance_for_deployment.html">Tuning Performance for Deployment</a></dt><dd>
        <p>This guide covers performance and concurrency configuration for deploying your production Ruby on Rails application.</p>
</dd>  </dl>
  <h2>Advanced Active Record</h2>
  <dl class="guide-index-list">
      <dt><a href="active_record_postgresql.html">Active Record and PostgreSQL</a></dt><dd class="interstitial work-in-progress">Work in progress</dd><dd>
        <p>This guide covers PostgreSQL specific usage of Active Record.</p>
</dd>      <dt><a href="active_record_multiple_databases.html">Multiple Databases</a></dt><dd>
        <p>This guide covers using multiple databases in your application.</p>
</dd>      <dt><a href="active_record_encryption.html">Active Record Encryption</a></dt><dd class="interstitial work-in-progress">Work in progress</dd><dd>
        <p>This guide covers encrypting your database information using Active Record.</p>
</dd>      <dt><a href="active_record_composite_primary_keys.html">Composite Primary Keys</a></dt><dd>
        <p>This guide is an introduction to composite primary keys for database tables.</p>
</dd>  </dl>
  <h2>Extending Rails</h2>
  <dl class="guide-index-list">
      <dt><a href="plugins.html">The Basics of Creating Rails Plugins</a></dt><dd class="interstitial work-in-progress">Work in progress</dd><dd>
        <p>This guide covers how to build a plugin to extend the functionality of Rails.</p>
</dd>      <dt><a href="rails_on_rack.html">Rails on Rack</a></dt><dd>
        <p>This guide covers Rails integration with Rack and interfacing with other Rack components.</p>
</dd>      <dt><a href="generators.html">Creating and Customizing Rails Generators &amp; Templates</a></dt><dd>
        <p>This guide covers the process of adding a brand new generator to your extension or providing an alternative to an element of a built-in Rails generator (such as providing alternative test stubs for the scaffold generator).</p>
</dd>      <dt><a href="engines.html">Getting Started with Engines</a></dt><dd class="interstitial work-in-progress">Work in progress</dd><dd>
        <p>Engines can be considered miniature applications that provide additional functionality to their host applications. In this guide you will learn how to create your own engine and integrate it with a host application.
</p>
</dd>      <dt><a href="rails_application_templates.html">Rails Application Templates</a></dt><dd class="interstitial work-in-progress">Work in progress</dd><dd>
        <p>Application templates are simple Ruby files containing DSL for adding gems, initializers, etc. to your freshly created Rails project or an existing Rails project.
</p>
</dd>      <dt><a href="threading_and_code_execution.html">Threading and Code Execution in Rails</a></dt><dd class="interstitial work-in-progress">Work in progress</dd><dd>
        <p>This guide describes the considerations needed and tools available when working directly with concurrency in a Rails application.</p>
</dd>  </dl>
  <h2>Contributing</h2>
  <dl class="guide-index-list">
      <dt><a href="contributing_to_ruby_on_rails.html">Contributing to Ruby on Rails</a></dt><dd>
        <p>Rails is not "someone else's framework". This guide covers a variety of ways that you can get involved in the ongoing development of Rails.</p>
</dd>      <dt><a href="api_documentation_guidelines.html">API Documentation Guidelines</a></dt><dd>
        <p>This guide documents the Ruby on Rails API documentation guidelines.</p>
</dd>      <dt><a href="ruby_on_rails_guides_guidelines.html">Guides Guidelines</a></dt><dd>
        <p>This guide documents the Ruby on Rails guides guidelines.</p>
</dd>      <dt><a href="development_dependencies_install.html">Installing Rails Core Development Dependencies</a></dt><dd>
        <p>This guide covers how to set up an environment for Ruby on Rails core development.</p>
</dd>  </dl>
  <h2>Policies</h2>
  <dl class="guide-index-list">
      <dt><a href="maintenance_policy.html">Maintenance Policy</a></dt><dd>
        <p>What versions of Ruby on Rails are currently supported, and when to expect new versions.</p>
</dd>  </dl>
  <h2>Release Notes</h2>
  <dl class="guide-index-list">
      <dt><a href="upgrading_ruby_on_rails.html">Upgrading Ruby on Rails</a></dt><dd>
        <p>This guide provides steps to be followed when you upgrade your applications to a newer version of Ruby on Rails.
</p>
</dd>      <dt><a href="8_0_release_notes.html">Version 8.0 - ?</a></dt><dd class="interstitial work-in-progress">Work in progress</dd><dd>
        <p>Release notes for Rails 8.0.</p>
</dd>      <dt><a href="7_2_release_notes.html">Version 7.2 - August 2024</a></dt><dd>
        <p>Release notes for Rails 7.2.</p>
</dd>      <dt><a href="7_1_release_notes.html">Version 7.1 - October 2023</a></dt><dd>
        <p>Release notes for Rails 7.1.</p>
</dd>      <dt><a href="7_0_release_notes.html">Version 7.0 - December 2021</a></dt><dd>
        <p>Release notes for Rails 7.0.</p>
</dd>      <dt><a href="6_1_release_notes.html">Version 6.1 - December 2020</a></dt><dd>
        <p>Release notes for Rails 6.1.</p>
</dd>      <dt><a href="6_0_release_notes.html">Version 6.0 - August 2019</a></dt><dd>
        <p>Release notes for Rails 6.0.</p>
</dd>      <dt><a href="5_2_release_notes.html">Version 5.2 - April 2018</a></dt><dd>
        <p>Release notes for Rails 5.2.</p>
</dd>      <dt><a href="5_1_release_notes.html">Version 5.1 - April 2017</a></dt><dd>
        <p>Release notes for Rails 5.1.</p>
</dd>      <dt><a href="5_0_release_notes.html">Version 5.0 - June 2016</a></dt><dd>
        <p>Release notes for Rails 5.0.</p>
</dd>      <dt><a href="4_2_release_notes.html">Version 4.2 - December 2014</a></dt><dd>
        <p>Release notes for Rails 4.2.</p>
</dd>      <dt><a href="4_1_release_notes.html">Version 4.1 - April 2014</a></dt><dd>
        <p>Release notes for Rails 4.1.</p>
</dd>      <dt><a href="4_0_release_notes.html">Version 4.0 - June 2013</a></dt><dd>
        <p>Release notes for Rails 4.0.</p>
</dd>      <dt><a href="3_2_release_notes.html">Version 3.2 - January 2012</a></dt><dd>
        <p>Release notes for Rails 3.2.</p>
</dd>      <dt><a href="3_1_release_notes.html">Version 3.1 - August 2011</a></dt><dd>
        <p>Release notes for Rails 3.1.</p>
</dd>      <dt><a href="3_0_release_notes.html">Version 3.0 - August 2010</a></dt><dd>
        <p>Release notes for Rails 3.0.</p>
</dd>      <dt><a href="2_3_release_notes.html">Version 2.3 - March 2009</a></dt><dd>
        <p>Release notes for Rails 2.3.</p>
</dd>      <dt><a href="2_2_release_notes.html">Version 2.2 - November 2008</a></dt><dd>
        <p>Release notes for Rails 2.2.</p>
</dd>  </dl>

        <hr>
        <h3>Feedback</h3>
        <p>
          You're encouraged to help improve the quality of this guide.
        </p>
        <p>
          Please contribute if you see any typos or factual errors.
          To get started, you can read our <a href="https://edgeguides.rubyonrails.org/contributing_to_ruby_on_rails.html#contributing-to-the-rails-documentation">documentation contributions</a> section.
        </p>
        <p>
          You may also find incomplete content or stuff that is not up to date.
          Please do add any missing documentation for main. Make sure to check
          <a href="https://edgeguides.rubyonrails.org">Edge Guides</a> first to verify
          if the issues are already fixed or not on the main branch.
          Check the <a href="ruby_on_rails_guides_guidelines.html">Ruby on Rails Guides Guidelines</a>
          for style and conventions.
        </p>
        <p>
          If for whatever reason you spot something to fix but cannot patch it yourself, please
          <a href="https://github.com/rails/rails/issues">open an issue</a>.
        </p>
        <p>And last but not least, any kind of discussion regarding Ruby on Rails
          documentation is very welcome on the <a href="https://discuss.rubyonrails.org/c/rubyonrails-docs">official Ruby on Rails Forum</a>.
        </p>
      </div>
    </div>
  </main>

  <hr class="hide">
  <footer id="page_footer">
    <div class="wrapper">
      <p>This work is licensed under a <a href="https://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International</a> License</p>
<p>"Rails", "Ruby on Rails", and the Rails logo are trademarks of David Heinemeier Hansson. All rights reserved.</p>

    </div>
  </footer>


<a class="back-to-top" href="#"></a></body></html>
