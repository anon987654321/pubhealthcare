class RAGSystem
  def initialize(weaviate_helper)
    @weaviate_helper = weaviate_helper
  end

  # Handles user queries by augmenting model responses with retrieved data
  def handle_query(query)
    relevant_data = @weaviate_helper.retrieve(query)
    augment_with_data(query, relevant_data)
  end

  private

  # Combines LLM response with retrieved data
  def augment_with_data(query, data)
    "Augmented Response to '#{query}': #{data}"
  end
end
