class FeedbackManager
  def initialize
    @feedback_log = []
  end

  def collect_feedback(user_id, feedback)
    @feedback_log << { user: user_id, feedback: feedback }
    puts "Feedback collected for user #{user_id}: #{feedback}"
  end

  def display_feedback
    @feedback_log.each do |entry|
      puts "User #{entry[:user]}: #{entry[:feedback]}"
    end
  end
end
