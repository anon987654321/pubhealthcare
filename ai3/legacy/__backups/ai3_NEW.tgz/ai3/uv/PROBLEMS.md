./docs.rb -- 3 warnings:
  [65]:TooManyStatements: download_repo has approx 6 statements [https://github.com/troessner/reek/blob/v6.3.0/docs/Too-Many-Statements.md]
  [69]:UncommunicativeVariableName: download_repo has the variable name 'e' [https://github.com/troessner/reek/blob/v6.3.0/docs/Uncommunicative-Variable-Name.md]
  [65]:UtilityFunction: download_repo doesn't depend on instance state (maybe move it to another class?) [https://github.com/troessner/reek/blob/v6.3.0/docs/Utility-Function.md]
Inspecting 1 file
C

Offenses:

docs.rb:1:1: C: [Correctable] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
#!/usr/bin/env ruby
^
docs.rb:9:14: C: [Correctable] Style/MutableConstant: Freeze mutable objects assigned to constants.
OUTPUT_DIR = '__docs'
             ^^^^^^^^
docs.rb:57:101: C: Layout/LineLength: Line is too long. [117/100]
  scraper.logger.info("Processing batch #{index + 1} of #{(web_urls.size / scraper.options[:batch_size].to_f).ceil}")
                                                                                                    ^^^^^^^^^^^^^^^^^
docs.rb:58:3: C: [Correctable] Style/HashEachMethods: Use each_value instead of each and remove the unused _name block argument.
  url_batch.each do |_name, url| ...
  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
docs.rb:67:7: C: Security/Open: The use of URI.open is a serious security risk.
  URI.open(repo_url) { |uri_data| File.write(zip_file_path, uri_data.read) }
      ^^^^

1 file inspected, 5 offenses detected, 3 more offenses can be corrected with `rubocop -A`
./universal_scraper.rb -- 15 warnings:
  [141, 142]:DuplicateMethodCall: UniversalScraper#handle_scraping_error calls 'error.message' 2 times [https://github.com/troessner/reek/blob/v6.3.0/docs/Duplicate-Method-Call.md]
  [24, 28]:DuplicateMethodCall: UniversalScraper#initialize calls 'ENV['OPENAI_API_KEY']' 2 times [https://github.com/troessner/reek/blob/v6.3.0/docs/Duplicate-Method-Call.md]
  [56, 67]:DuplicateMethodCall: UniversalScraper#scrape calls '@options[:adaptive_learning]' 2 times [https://github.com/troessner/reek/blob/v6.3.0/docs/Duplicate-Method-Call.md]
  [123, 123, 123]:FeatureEnvy: UniversalScraper#apply_custom_rules refers to 'rule' more than self (maybe move it to another class?) [https://github.com/troessner/reek/blob/v6.3.0/docs/Feature-Envy.md]
  [13]:IrresponsibleModule: UniversalScraper has no descriptive comment [https://github.com/troessner/reek/blob/v6.3.0/docs/Irresponsible-Module.md]
  [56, 67, 142]:RepeatedConditional: UniversalScraper tests '@options[:adaptive_learning]' at least 3 times [https://github.com/troessner/reek/blob/v6.3.0/docs/Repeated-Conditional.md]
  [13]:TooManyMethods: UniversalScraper has at least 20 methods [https://github.com/troessner/reek/blob/v6.3.0/docs/Too-Many-Methods.md]
  [100]:TooManyStatements: UniversalScraper#respect_robots_txt has approx 7 statements [https://github.com/troessner/reek/blob/v6.3.0/docs/Too-Many-Statements.md]
  [168]:TooManyStatements: UniversalScraper#save_if_changed has approx 6 statements [https://github.com/troessner/reek/blob/v6.3.0/docs/Too-Many-Statements.md]
  [52]:TooManyStatements: UniversalScraper#scrape has approx 13 statements [https://github.com/troessner/reek/blob/v6.3.0/docs/Too-Many-Statements.md]
  [174]:UncommunicativeVariableName: UniversalScraper#save_if_changed has the variable name 'e' [https://github.com/troessner/reek/blob/v6.3.0/docs/Uncommunicative-Variable-Name.md]
  [69]:UncommunicativeVariableName: UniversalScraper#scrape has the variable name 'e' [https://github.com/troessner/reek/blob/v6.3.0/docs/Uncommunicative-Variable-Name.md]
  [152]:UncommunicativeVariableName: UniversalScraper#with_error_handling has the variable name 'e' [https://github.com/troessner/reek/blob/v6.3.0/docs/Uncommunicative-Variable-Name.md]
  [178]:UtilityFunction: UniversalScraper#content_has_changed? doesn't depend on instance state (maybe move it to another class?) [https://github.com/troessner/reek/blob/v6.3.0/docs/Utility-Function.md]
  [187]:UtilityFunction: UniversalScraper#sanitize_filename doesn't depend on instance state (maybe move it to another class?) [https://github.com/troessner/reek/blob/v6.3.0/docs/Utility-Function.md]
Inspecting 1 file
C

Offenses:

universal_scraper.rb:1:1: C: [Correctable] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
# universal_scraper.rb
^
universal_scraper.rb:13:1: C: Metrics/ClassLength: Class has too many lines. [160/100]
class UniversalScraper ...
^^^^^^^^^^^^^^^^^^^^^^
universal_scraper.rb:13:1: C: Style/Documentation: Missing top-level documentation comment for class UniversalScraper.
class UniversalScraper
^^^^^^^^^^^^^^^^^^^^^^
universal_scraper.rb:16:17: C: [Correctable] Style/MutableConstant: Freeze mutable objects assigned to constants.
  USER_AGENTS = [ ...
                ^
universal_scraper.rb:17:101: C: Layout/LineLength: Line is too long. [121/100]
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
                                                                                                    ^^^^^^^^^^^^^^^^^^^^^
universal_scraper.rb:18:101: C: Layout/LineLength: Line is too long. [126/100]
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2 Safari/605.1.15',
                                                                                                    ^^^^^^^^^^^^^^^^^^^^^^^^^^
universal_scraper.rb:20:101: C: Layout/LineLength: Line is too long. [142/100]
    'Mozilla/5.0 (Linux; Android 7.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.116 Mobile Safari/537.36'
                                                                                                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
universal_scraper.rb:23:3: C: Metrics/MethodLength: Method has too many lines. [24/15]
  def initialize(options = {}) ...
  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^
universal_scraper.rb:52:3: C: Metrics/MethodLength: Method has too many lines. [16/15]
  def scrape(url) ...
  ^^^^^^^^^^^^^^^
universal_scraper.rb:84:16: C: [Correctable] Style/GlobalStdStream: Use $stdout instead of STDOUT.
    Logger.new(STDOUT).tap do |log|
               ^^^^^^
universal_scraper.rb:103:28: C: Security/Open: The use of URI.open is a serious security risk.
      robots_content = URI.open(robots_url).read
                           ^^^^
universal_scraper.rb:179:101: C: Layout/LineLength: Line is too long. [118/100]
    !File.exist?(file_path) || Digest::SHA256.hexdigest(File.read(file_path)) != Digest::SHA256.hexdigest(new_content)
                                                                                                    ^^^^^^^^^^^^^^^^^^

1 file inspected, 12 offenses detected, 3 more offenses can be corrected with `rubocop -A`
./README.md:8: MD009 Trailing spaces
./README.md:10: MD009 Trailing spaces
./README.md:12: MD009 Trailing spaces
./README.md:14: MD009 Trailing spaces
./README.md:16: MD009 Trailing spaces
./README.md:32: MD009 Trailing spaces
./README.md:3: MD013 Line length
./README.md:7: MD013 Line length
./README.md:9: MD013 Line length
./README.md:11: MD013 Line length
./README.md:13: MD013 Line length
./README.md:15: MD013 Line length
./README.md:17: MD013 Line length
./README.md:21: MD013 Line length
./README.md:23: MD013 Line length
./README.md:27: MD013 Line length
./README.md:31: MD013 Line length
./README.md:33: MD013 Line length
./README.md:37: MD013 Line length

Further documentation is available for these failures:
 - MD009: https://github.com/markdownlint/markdownlint/blob/main/docs/RULES.md#md009---trailing-spaces
 - MD013: https://github.com/markdownlint/markdownlint/blob/main/docs/RULES.md#md013---line-length
