
# ai3.rb

require 'langchainrb'

# Initialize AI3 and handle multiple assistants dynamically

class AI3
  attr_reader :assistants

  def initialize
    # Define all available assistants
    @assistants = {
      lawyer: LawyerAssistant.new,
      architect: ArchitectAssistant.new,
      hacker: EthicalHacker.new,
      doctor: MedicalAssistant.new,
      seo: SEOExpert.new,
      propulsion: PropulsionEngineer.new
    }
  end

  # Select and run an assistant based on user input
  def run_assistant
    puts "Choose an assistant:"
    @assistants.keys.each_with_index do |assistant, index|
      puts "#{index + 1}. #{assistant.capitalize} Assistant"
    end
    choice = gets.chomp.to_i
    selected_assistant = @assistants.values[choice - 1]

    if selected_assistant
      puts "You selected #{selected_assistant.class}. Now ask a question or request a task."
      query = gets.chomp
      selected_assistant.handle_request(query)
    else
      puts "Invalid choice."
    end
  end
end

# Main interface
ai3 = AI3.new
ai3.run_assistant

