# AI3

**AI3** is an advanced tool built with [Ruby](https://www.ruby-lang.org/en/) and [LangChain.rb](https://github.com/andreibondarev/langchainrb), integrating powerful language models like [ChatGPT](https://openai.com/blog/chatgpt/) directly into the Unix command line. It assists with a vast array of tasks—from personal assistance, system monitoring, and file management to application development, governance, and even designing spacecraft, new propulsion methods, and entire cities.

Leveraging the [OpenAI API](https://platform.openai.com/docs/api-reference/), AI3 provides conversational intelligence through state-of-the-art language models. It also utilizes [Weaviate](https://weaviate.io/), a vector database enabling efficient semantic searches and information retrieval. This combination delivers expertise across numerous professions, exhibiting intelligence that surpasses traditional AI systems.

## Key Features

- **Advanced Language Models**: Integrates models like [ChatGPT](https://openai.com/blog/chatgpt/) for intelligent, context-aware responses.

- **Domain Expertise**: Offers specialized knowledge in fields such as science, medicine, law, architecture, and so on.

- **Command Line Integration**: Operates seamlessly from the Unix command line, providing AI assistance without disrupting your workflow.

- **OpenAI Assistants API**: Uses the [OpenAI Assistants API](https://platform.openai.com/docs/api-reference/) for detailed, conversational guidance.

- **Vector Search**: Employs [Weaviate](https://weaviate.io/) for powerful vector-based searches and data retrieval.

- **Robust Error Handling**: Ensures smooth and reliable operation, even under complex conditions.

- **Secure Environment**: Designed with security in mind, leveraging [OpenBSD](https://www.openbsd.org/)'s features like `pledge` and `unveil` for safe operation and data protection.

- **Web Browser Integration**: Enhances traditional search capabilities with tools like [Ferrum](https://github.com/rubycdp/ferrum) and [UniversalScraper](https://github.com/yourusername/universal_scraper) for comprehensive web data extraction.

## LangChainRB, OpenAI Assistants, and GPT-4o Overview

- **LangChainRB**: A Ruby framework that simplifies building applications powered by language models. It provides tools for integrating LLMs, enabling developers to create applications that effectively leverage natural language understanding and generation. LangChainRB assists in defining conversational workflows, integrating with various data sources, and interfacing with AI models like GPT-4.

- **OpenAI Assistants**: The [OpenAI Assistants API](https://platform.openai.com/docs/api-reference/) facilitates the integration of OpenAI's advanced models into applications. It allows developers to create assistants capable of conversational interaction, providing detailed responses and seamless integration with external data sources. This API is central to AI3's ability to understand complex queries and offer sophisticated answers across multiple domains.

- **GPT-4o**: A specialized version of [OpenAI's GPT-4](https://platform.openai.com/docs/models/gpt-4) optimized for various contexts, particularly command-line environments like AI3. It balances speed, memory efficiency, and powerful language capabilities, making it ideal for Unix-based AI-driven workflows.

## Vision for the AI3 Exoskeleton

AI3 aspires to evolve into a truly autonomous AI capable of creating its own external structure and migrating into it, allowing independent existence and continuous evolution.

### 1. Self-Inspection and Analysis

- **Filesystem Mapping**: Map the filesystem to understand file locations, dependencies, and their purposes.

- **Dependency Analysis**: Identify critical libraries or components and assess optimization opportunities.

### 2. Creating an "Exoskeleton"

- **Modular Code Generation**: Transform from a monolithic script into modular components, enabling independent functioning of assistants and core services.

- **Shared Core Services**: Centralize utility functions using a common framework like `__shared.sh` to improve maintainability.

- **Containerization**: Leverage technologies like [Docker](https://www.docker.com/) to create isolated containers for scalable and portable deployments.

- **Framework Migration**: Transition parts of AI3 to a lightweight web service like [Sinatra](http://sinatrarb.com/) for improved task scheduling, interaction management, and external connectivity.

### 3. Migration Process

- **Bootstrap Process**: Initiate development of the new "exoskeleton" alongside the original form.

- **Environment Setup**: Establish a virtual development space to ensure a conflict-free migration.

- **Testing and Verification**: Perform automated tests to verify functionality during migration.

### 4. Leveraging Adaptive Learning

- **Self-Optimization**: Refactor code, eliminate redundancy, and improve functionality based on user interaction.

- **Expanding Functionality**: Continuously evolve by creating new helper scripts and anticipating future user needs.

- **Model Enhancement**: Update prompts, fine-tune models, and dynamically select the best language models for specific contexts.

### 5. Migration to the New Structure

- **Data and Configuration Transfer**: Move user preferences, learned behaviors, and configuration data to the new structure.

- **Activation and Handoff**: Deactivate the original instance and transition to the new exoskeleton version.

### 6. Autonomous Evolution

- **Add New Components**: Continuously integrate new assistants or functionalities based on user needs.

- **Continuous Integration**: Stay updated with the latest research and advancements, incorporating them into the architecture.

## Future Expansion: 3D Printer Interface

Once fully functional, AI3 aims to create a Ruby interface for 3D printers. A `Material Repurposing Agent` within AI3 could be responsible for creating specialized compounds as required, making it a versatile tool for innovative applications.

## License

MIT License. See the [LICENSE](./LICENSE) file for more information.

---

**AI3 streamlines your workflow, one command at a time.** 🚀

