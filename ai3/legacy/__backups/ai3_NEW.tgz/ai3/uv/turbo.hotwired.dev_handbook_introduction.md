You are analyzing the following web page: https://turbo.hotwired.dev/handbook/introduction.
Here is the page content and a screenshot (turbo.hotwired.dev_handbook_introduction.png).
Please identify the most important sections to scrape, considering the presence of dynamic content, pagination, and nested structures.
Focus on key sections, headings, or elements based on the content provided:
<html lang="en"><head><style type="text/css">.turbo-progress-bar {
  position: fixed;
  display: block;
  top: 0;
  left: 0;
  height: 3px;
  background: #0076ff;
  z-index: 2147483647;
  transition:
    width 300ms ease-out,
    opacity 150ms 150ms ease-in;
  transform: translate3d(0, 0, 0);
}
</style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Turbo Handbook</title>
  <meta name="description" content="Turbo bundles several techniques for creating fast, modern web applications without having to reach for a client-side JavaScript framework.">
  <link rel="canonical" href="https://turbo.hotwired.dev/handbook/introduction">

  <link rel="alternate icon" type="image/png" sizes="32x32" href="/assets/favicon-32x32.png">
  <link rel="icon" type="image/svg+xml" href="/assets/favicon.svg">
  <link rel="mask-icon" href="/assets/favicon.svg" color="#000000">
  <link rel="apple-touch-icon" href="/assets/favicon-196x196.png">

  <link rel="preload" href="/assets/fonts/Bitter-Roman.woff2" as="font" type="font/woff2" crossorigin="">
  <link rel="preload" href="/assets/fonts/Bitter-Italic.woff2" as="font" type="font/woff2" crossorigin="">
  <link rel="preload" href="/assets/fonts/Jost-Roman.woff2" as="font" type="font/woff2" crossorigin="">
  <link rel="preload" href="/assets/fonts/Jost-Italic.woff2" as="font" type="font/woff2" crossorigin="">
  <link rel="preload" href="/assets/fonts/RobotoMono-Roman.woff2" as="font" type="font/woff2" crossorigin="">
  <link rel="preload" href="/assets/fonts/RobotoMono-Italic.woff2" as="font" type="font/woff2" crossorigin="">

  <link rel="stylesheet" href="/assets/main.css">
  <script src="/assets/main.js" type="module"></script>
  <script defer="" data-domain="turbo.hotwired.dev" src="https://plausible.io/js/script.js"></script>
</head>


  <body>

    <a class="nav-skip" href="#content">Skip to content</a>

<nav class="jump">
  <ul class="jump__list">
    <li><a class="jump__list-link jump__list-link--hotwire" href="https://hotwired.dev">Hotwire:</a></li>
    <li><a class="jump__list-link jump__list-link--active" href="https://turbo.hotwired.dev">Turbo</a></li>
    <li><a class="jump__list-link" href="https://stimulus.hotwired.dev">Stimulus</a></li>
    <li><a class="jump__list-link" href="https://native.hotwired.dev">Native</a></li>
  </ul>
</nav>


    
<div class="nav__github-corner">
  <svg width="60" height="60" viewBox="0 0 250 250" version="1.1" xmlns="github-corner" style="fill:#000000; color:#FFFFFF;" aria-hidden="true">
	<a href="https://github.com/hotwired/turbo-site/blob/main/./_source/handbook/01_introduction.md" target="_blank" class="github-corner">
		<path d="M0,0 L115,115 L130,115 L142,142 L250,250 L250,0 Z"></path>
		<path d="M128.3,109.0 C113.8,99.7 119.0,89.6 119.0,89.6 C122.0,82.7 120.5,78.6 120.5,78.6 C119.2,72.0 123.4,76.3 123.4,76.3 C127.3,80.9 125.5,87.3 125.5,87.3 C122.9,97.6 130.6,101.9 134.4,103.2" fill="#FFFFFF" style="transform-origin: 130px 106px;" class="octo-arm">
		</path>
		<path d="M115.0,115.0 C114.9,115.1 118.7,116.5 119.8,115.4 L133.7,101.6 C136.9,99.2 139.9,98.4 142.2,98.6 C133.8,88.0 127.5,74.4 143.8,58.0 C148.5,53.4 154.0,51.2 159.7,51.0 C160.3,49.4 163.2,43.6 171.4,40.1 C171.4,40.1 176.1,42.5 178.8,56.2 C183.1,58.6 187.2,61.8 190.9,65.4 C194.5,69.0 197.7,73.2 200.1,77.6 C213.8,80.2 216.3,84.9 216.3,84.9 C212.7,93.1 206.9,96.0 205.4,96.6 C205.1,102.4 203.0,107.8 198.3,112.5 C181.9,128.9 168.3,122.5 157.7,114.1 C157.9,116.9 156.7,120.9 152.7,124.9 L141.0,136.5 C139.8,137.7 141.6,141.9 141.8,141.8 Z" fill="#FFFFFF" class="octo-body">
		</path>
	</a>
</svg>

</div>

<main class="grid docs">

  <header class="docs__index grid__custom-item">
    <a class="nav-logo" href="/" aria-label="Turbo">
  <svg class="logo" width="271" height="60" viewBox="0 0 271 60" xmlns="http://www.w3.org/2000/svg">
  <g class="logo__icon" fill="#5CD8E5">
    <path d="M9.56852 30C9.56511 26.8506 10.2914 23.7556 11.6756 20.9528C12.0902 20.1134 12.2975 19.6937 12.256 19.4195C12.2174 19.1644 12.0999 18.9753 11.8882 18.8277C11.6608 18.6692 11.2256 18.6692 10.3552 18.6692H1.41176C0.917599 18.6692 0.670518 18.6692 0.481772 18.7653C0.315747 18.8499 0.180765 18.9849 0.0961706 19.1509C0 19.3397 1.99791e-10 19.5868 1.99791e-10 20.0809V58.1679C-3.56516e-06 58.4093 0.0477119 58.6484 0.140403 58.8713C0.233095 59.0943 0.368934 59.2967 0.540113 59.4669C0.711291 59.6372 0.914432 59.7719 1.13786 59.8634C1.36128 59.9549 1.60059 60.0013 1.84201 60H58.1678C58.6537 60 59.1197 59.807 59.4633 59.4634C59.8069 59.1198 59.9999 58.6538 59.9999 58.1679V51.8432C59.9999 51.3491 59.9999 51.102 59.9037 50.9132C59.8191 50.7472 59.6841 50.6122 59.5181 50.5276C59.3294 50.4315 59.0823 50.4315 58.5881 50.4315H29.9999C24.5812 50.4315 19.3844 48.2789 15.5527 44.4472C11.7211 40.6156 9.56852 35.4188 9.56852 30Z"></path>
    <path d="M39.1503 30.8662C41.1033 30.6502 43.0206 30.1851 44.8555 29.4822V29.4125C45.3982 29.2448 45.9847 29.2923 46.4932 29.5454C47.0018 29.7985 47.3934 30.2376 47.5868 30.7717C47.7802 31.3058 47.7605 31.8939 47.5319 32.4139C47.3033 32.9339 46.8833 33.3459 46.359 33.5645C43.688 34.6173 40.855 35.2001 37.9853 35.2871H37.4775C36.9653 35.9997 36.3553 36.6365 35.6654 37.1789C36.8401 38.3313 38.1391 39.3498 39.5386 40.2157C40.0324 40.5286 40.3817 41.0249 40.5096 41.5953C40.6375 42.1658 40.5336 42.7637 40.2206 43.2575C39.9077 43.7513 39.4114 44.1006 38.841 44.2285C38.2705 44.3564 37.6726 44.2525 37.1788 43.9396C35.0088 42.6156 33.0601 40.9592 31.4039 39.0308C30.9391 39.0994 30.4697 39.1326 29.9999 39.1304H29.1038C29.1745 39.8644 29.2942 40.5929 29.4623 41.311C29.6017 41.9382 29.7809 42.5954 29.9999 43.3023C30.1131 43.7096 30.2434 44.0712 30.3821 44.4564C30.4265 44.5796 30.4718 44.7053 30.5177 44.8357C30.6617 45.2298 30.6895 45.6571 30.5977 46.0666C30.506 46.4761 30.2985 46.8507 29.9999 47.1457C29.7733 47.3718 29.502 47.5481 29.2034 47.6634C28.9605 47.7498 28.7045 47.7936 28.4467 47.7928C28.0011 47.7962 27.5651 47.6637 27.1969 47.4128C26.8286 47.162 26.5456 46.8048 26.3856 46.3889C25.7728 44.7567 25.3031 43.0743 24.9817 41.3607C24.7338 40.092 24.627 38.7997 24.6631 37.5074C23.9549 36.99 23.3187 36.3806 22.7713 35.6953C21.6315 36.8686 20.6294 38.168 19.7842 39.5685C19.582 39.8793 19.3042 40.1338 18.9768 40.3079C18.6494 40.4821 18.2831 40.5702 17.9123 40.5642C17.517 40.5656 17.1286 40.4604 16.788 40.2598C16.4474 40.0592 16.1671 39.7706 15.9765 39.4242C15.786 39.0778 15.6924 38.6865 15.7054 38.2914C15.7184 37.8963 15.8375 37.512 16.0504 37.1789C17.3747 35.0033 19.0348 33.0509 20.9691 31.3939C20.8972 30.9327 20.8606 30.4667 20.8596 30C20.8596 29.8506 20.872 29.7013 20.8845 29.5519C20.8969 29.4026 20.9093 29.2532 20.9093 29.1039C18.9244 29.3268 16.9767 29.8054 15.1145 30.5277C14.5652 30.7284 13.9587 30.7027 13.4284 30.4562C12.8981 30.2097 12.4874 29.7627 12.2867 29.2134C12.086 28.6641 12.1118 28.0576 12.3582 27.5273C12.6047 26.997 13.0518 26.5864 13.601 26.3857C16.4269 25.2464 19.4456 24.6616 22.4925 24.6631C23.0043 23.9503 23.6144 23.3134 24.3046 22.7713C23.1256 21.634 21.8231 20.6321 20.4215 19.7843C19.9525 19.4598 19.6271 18.9666 19.5132 18.4078C19.3994 17.8489 19.506 17.2677 19.8106 16.7856C20.1153 16.3036 20.5945 15.9579 21.1481 15.8209C21.7017 15.6839 22.2869 15.7661 22.7812 16.0505C24.9578 17.3774 26.9131 19.0371 28.5761 20.9691C29.3334 20.847 30.1036 20.8269 30.8662 20.9094C30.8066 20.1436 30.7002 19.3821 30.5476 18.6293C30.3982 18.012 30.219 17.3449 29.9999 16.6379C29.8506 16.1102 29.6813 15.6422 29.4822 15.1145C29.3398 14.7185 29.3128 14.2902 29.4045 13.8794C29.4961 13.4687 29.7026 13.0925 29.9999 12.7946C30.2263 12.5658 30.5023 12.392 30.8064 12.2868C31.0784 12.1868 31.3674 12.1415 31.6568 12.1535C31.9463 12.1655 32.2306 12.2345 32.4933 12.3566C32.756 12.4787 32.9921 12.6515 33.1878 12.8651C33.3836 13.0786 33.5353 13.3288 33.6342 13.6011C34.2423 15.2348 34.7119 16.9168 35.0381 18.6293C35.2785 19.9023 35.382 21.1975 35.3468 22.4925C36.0614 22.9984 36.6987 23.6055 37.2386 24.2947C38.3931 23.1218 39.4118 21.8226 40.2754 20.4215C40.5883 19.9277 41.0846 19.5784 41.655 19.4505C42.2255 19.3226 42.8234 19.4265 43.3172 19.7395C43.811 20.0524 44.1603 20.5487 44.2882 21.1191C44.4161 21.6896 44.3122 22.2875 43.9992 22.7813C42.6752 24.9542 41.0189 26.9062 39.0905 28.5662C39.1993 29.328 39.2193 30.0998 39.1503 30.8662ZM34.8987 30.3983V30H34.9385C34.9245 29.0863 34.6592 28.1941 34.1719 27.4212C34.043 27.2069 33.8964 27.0037 33.7337 26.8138C33.053 26.0132 32.1364 25.4486 31.1151 25.2008C30.8665 25.1408 30.6134 25.1009 30.3584 25.0813H29.9601C29.0502 25.0834 28.1583 25.3348 27.3813 25.8082C27.1675 25.9461 26.9614 26.0957 26.764 26.2562C25.9671 26.9384 25.406 27.8549 25.1609 28.8749C25.101 29.1201 25.061 29.3699 25.0414 29.6216V30.0199C25.0435 30.9298 25.2949 31.8217 25.7683 32.5987C25.9038 32.8142 26.0535 33.0204 26.2163 33.216C26.6345 33.7126 27.1475 34.1208 27.7254 34.4165C28.3033 34.7123 28.9344 34.8898 29.5817 34.9386H29.98C30.8899 34.9365 31.7818 34.6851 32.5588 34.2117C32.7731 34.0829 32.9763 33.9363 33.1662 33.7736C33.6658 33.3552 34.0764 32.841 34.374 32.2613C34.6716 31.6815 34.85 31.0481 34.8987 30.3983Z"></path>
    <path d="M58.1678 0H1.84201C1.35348 0 0.884958 0.194069 0.539513 0.539513C0.194069 0.884958 1.99791e-10 1.35348 1.99791e-10 1.84201V8.15675C1.99791e-10 8.65092 0 8.898 0.0961706 9.08674C0.180765 9.25277 0.315747 9.38775 0.481772 9.47235C0.670518 9.56852 0.917599 9.56852 1.41176 9.56852H29.9999C33.6968 9.57103 37.3238 10.5761 40.4947 12.4766C43.6657 14.3771 46.2619 17.102 48.0069 20.3611C49.7519 23.6202 50.5804 27.2916 50.4042 30.9842C50.27 33.7965 49.5569 36.5409 48.3201 39.0493C47.9068 39.8877 47.7001 40.3068 47.7417 40.5808C47.7804 40.8358 47.898 41.0249 48.1096 41.1724C48.3369 41.3308 48.7715 41.3308 49.6408 41.3308H58.5383C59.0325 41.3308 59.2796 41.3308 59.4683 41.2346C59.6343 41.15 59.7693 41.0151 59.8539 40.849C59.9501 40.6603 59.9501 40.4132 59.9501 39.9191V1.84201C59.9529 1.36291 59.7679 0.901772 59.4347 0.557448C59.1015 0.213124 58.6468 0.0130114 58.1678 0Z"></path>
  </g>
  <g class="logo__wordmark" fill="#000">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M268.982 7.97267C269.989 8.76001 270.713 9.85401 271.043 11.0892C271.46 12.7535 271.484 14.492 271.113 16.1672L266.234 43.8173C265.97 45.6712 265.366 47.4604 264.452 49.0945C263.694 50.4052 262.636 51.5176 261.365 52.3404C260.048 53.1548 258.588 53.7123 257.064 53.9833C255.269 54.3001 253.449 54.4534 251.627 54.4413H240.197C238.424 54.4584 236.653 54.305 234.91 53.9833C233.563 53.754 232.296 53.189 231.226 52.3404C230.254 51.4971 229.589 50.3557 229.334 49.0945C229.001 47.3494 229.018 45.5558 229.384 43.8173L234.213 16.1672C234.497 14.3769 235.112 12.6551 236.025 11.0892C236.792 9.81721 237.854 8.74836 239.121 7.97267C240.433 7.18749 241.883 6.66028 243.393 6.4194C245.13 6.13052 246.889 5.99062 248.65 6.00121H260.081C261.806 5.98533 263.528 6.12529 265.228 6.4194C266.586 6.6278 267.874 7.16062 268.982 7.97267ZM243.373 42.3039H252.702L256.964 18.1585H247.634L243.373 42.3039ZM185.484 8.71942C186.479 9.55948 187.177 10.6976 187.475 11.9653C187.838 13.699 187.838 15.4889 187.475 17.2226L185.892 26.4227C185.674 27.6412 185.317 28.8305 184.827 29.9673C184.405 30.9394 183.833 31.8397 183.134 32.6358C182.466 33.3839 181.67 34.0075 180.784 34.4778C179.866 34.97 178.902 35.3734 177.907 35.6826H177.508L184.369 53.9036H169.324L164.087 37.7138H162.185L159.387 53.9036H145.656L153.861 6.56874H176.612C178.35 6.54946 180.085 6.70961 181.79 7.04667C183.14 7.29357 184.408 7.86796 185.484 8.71942ZM172.48 25.1283L173.416 19.9906H173.366C173.43 19.6929 173.444 19.3866 173.406 19.0845C173.36 18.8351 173.25 18.6019 173.088 18.4074C172.907 18.2171 172.686 18.0706 172.44 17.9793C172.12 17.8703 171.783 17.8198 171.445 17.8299H165.66L164.007 27.3288H169.782C170.119 27.3296 170.455 27.2793 170.778 27.1794C171.071 27.0894 171.345 26.9441 171.584 26.7513C171.825 26.5702 172.019 26.3348 172.152 26.0642C172.288 25.7624 172.398 25.4492 172.48 25.1283ZM133.708 6.56873L127.485 42.3039H119.37L125.593 6.56873H111.873L105.381 43.9268C104.995 45.6719 104.965 47.4767 105.291 49.2338C105.554 50.4987 106.234 51.6385 107.223 52.4698C108.308 53.3016 109.585 53.8461 110.937 54.0529C112.653 54.3514 114.393 54.4947 116.134 54.4811H126.37C128.181 54.492 129.99 54.3488 131.777 54.0529C133.295 53.8163 134.751 53.278 136.058 52.4698C137.323 51.6474 138.377 50.5389 139.135 49.2338C140.054 47.5886 140.668 45.7906 140.947 43.9268L147.439 6.56873H133.708ZM108.189 6.5787H73.0909L71 18.5767H81.6837L75.5304 53.9036H89.2509L95.4042 18.5767H106.088L108.189 6.5787ZM229.165 12.2342C228.926 10.9719 228.303 9.81408 227.382 8.91857C226.399 8.04609 225.216 7.43038 223.937 7.12633C222.344 6.73568 220.708 6.54833 219.068 6.56875H195.172L186.957 53.9036H211.372C213.074 53.9187 214.772 53.7315 216.43 53.346C217.889 52.9984 219.27 52.3803 220.502 51.5239C221.737 50.6396 222.758 49.4896 223.489 48.1585C224.34 46.5638 224.916 44.8369 225.192 43.0506L225.7 39.9341C225.912 38.7646 226.019 37.5782 226.018 36.3895C226.029 35.3715 225.857 34.3598 225.51 33.4025C225.198 32.5554 224.69 31.7944 224.027 31.1821C223.259 30.5156 222.365 30.011 221.398 29.6985C222.397 29.3452 223.34 28.8489 224.196 28.2249C225.003 27.6366 225.715 26.9281 226.307 26.124C226.904 25.3167 227.39 24.4325 227.751 23.4954C228.139 22.4536 228.426 21.3765 228.607 20.2793L229.155 17.2923C229.466 15.621 229.47 13.9067 229.165 12.2342ZM212.367 37.4748L211.73 41.0593C211.673 41.4561 211.566 41.8442 211.411 42.2143C211.279 42.5298 211.079 42.8121 210.824 43.0407C210.555 43.2632 210.243 43.4292 209.908 43.5286C209.491 43.6479 209.058 43.7049 208.624 43.6978H202.47L204.023 34.8064H210.177C210.533 34.7551 210.896 34.783 211.24 34.8879C211.584 34.9929 211.901 35.1724 212.168 35.4137C212.338 35.7265 212.442 36.0701 212.477 36.4241C212.511 36.7781 212.474 37.1354 212.367 37.4748ZM215.245 19.3832L214.767 22.3703C214.696 22.8051 214.572 23.2297 214.399 23.6348C214.267 23.9509 214.066 24.2333 213.811 24.4612C213.543 24.6828 213.23 24.8456 212.895 24.9391C212.471 25.0576 212.031 25.1146 211.591 25.1084H205.746L207.17 16.7845H213.015C213.439 16.7758 213.862 16.8329 214.269 16.9537C214.563 17.0445 214.826 17.2172 215.026 17.4516C215.203 17.6856 215.31 17.9654 215.334 18.2581C215.346 18.6368 215.306 19.0154 215.215 19.3832H215.245Z"></path>
    <path d="M268.312 7.68239C269.323 8.4722 270.048 9.56964 270.38 10.8087C270.798 12.4782 270.822 14.2222 270.45 15.9026L265.555 43.6396C265.291 45.4993 264.685 47.294 263.768 48.9333C263.007 50.2481 261.946 51.364 260.671 52.1894C259.35 53.0064 257.886 53.5656 256.356 53.8374C254.556 54.1553 252.731 54.3091 250.903 54.2969H239.437C237.658 54.314 235.882 54.1602 234.133 53.8374C232.782 53.6075 231.511 53.0406 230.437 52.1894C229.462 51.3434 228.795 50.1984 228.54 48.9333C228.206 47.1827 228.223 45.3835 228.589 43.6396L233.434 15.9026C233.719 14.1068 234.336 12.3795 235.252 10.8087C236.021 9.53272 237.087 8.46052 238.358 7.68239C239.674 6.89475 241.128 6.36588 242.643 6.12425C244.385 5.83446 246.15 5.69412 247.916 5.70475H259.383C261.113 5.68881 262.841 5.82922 264.547 6.12425C265.909 6.3333 267.2 6.86779 268.312 7.68239ZM242.623 42.1214H251.982L256.257 17.9002H246.898L242.623 42.1214ZM108.27 6.24931H73.0398L70.941 18.2925H81.665L75.4885 53.7524H89.2607L95.4372 18.2925H106.161L108.27 6.24931ZM133.806 6.24931L127.57 42.119H119.454L125.701 6.24931H111.938L105.422 43.7381C105.043 45.4942 105.015 47.3083 105.342 49.0751C105.602 50.3409 106.282 51.4819 107.271 52.3132C108.364 53.1482 109.649 53.6947 111.009 53.9023C112.728 54.2069 114.471 54.3508 116.216 54.3321H126.5C128.318 54.3476 130.134 54.2038 131.927 53.9023C133.45 53.6612 134.911 53.1211 136.225 52.3132C137.495 51.4917 138.553 50.3823 139.313 49.0751C140.23 47.4186 140.843 45.611 141.122 43.7381L147.618 6.24931H133.806ZM153.209 6.25092L144.951 53.7113L158.701 53.752L161.508 37.4798H163.406L168.654 53.752H183.733L176.858 35.5001H177.265C178.258 35.1872 179.22 34.7832 180.139 34.2932C181.026 33.8189 181.824 33.195 182.499 32.449C183.197 31.6378 183.764 30.7228 184.18 29.737C184.677 28.5947 185.037 27.3976 185.252 26.1707L186.838 16.9634C187.209 15.2292 187.209 13.4363 186.838 11.7021C186.557 10.4198 185.867 9.26344 184.872 8.40698C183.794 7.55254 182.523 6.97522 181.17 6.72553C179.464 6.39298 177.728 6.23397 175.99 6.25092H153.209ZM169.129 27.0928H163.338L165.006 17.5736H170.81C171.142 17.5682 171.472 17.6187 171.786 17.7228C172.036 17.8118 172.259 17.9609 172.437 18.1567C172.597 18.3526 172.704 18.5859 172.749 18.8347C172.804 19.135 172.804 19.4429 172.749 19.7432L171.881 24.8961C171.795 25.2127 171.682 25.5212 171.542 25.8182C171.415 26.0935 171.219 26.3316 170.973 26.5097C170.73 26.7019 170.454 26.8488 170.159 26.9436C169.825 27.0464 169.478 27.0967 169.129 27.0928ZM228.37 11.9364C228.13 10.6698 227.506 9.50785 226.582 8.60922C225.596 7.7337 224.409 7.11585 223.126 6.81074C221.528 6.41872 219.887 6.23072 218.242 6.25121H194.27L186.029 53.7511H210.521C212.228 53.7662 213.931 53.5784 215.595 53.1916C217.059 52.8427 218.444 52.2225 219.68 51.3631C220.919 50.4757 221.943 49.3217 222.676 47.986C223.53 46.3858 224.107 44.6528 224.384 42.8603L224.894 39.733C225.107 38.5593 225.214 37.3688 225.213 36.176C225.224 35.1544 225.052 34.1391 224.704 33.1785C224.391 32.3285 223.881 31.5648 223.216 30.9504C222.446 30.2816 221.549 29.7752 220.579 29.4616C221.581 29.1071 222.526 28.609 223.386 27.9829C224.195 27.3925 224.909 26.6815 225.503 25.8747C226.102 25.0645 226.589 24.1773 226.951 23.2369C227.341 22.1914 227.629 21.1106 227.81 20.0096L228.36 17.0121C228.672 15.335 228.676 13.6148 228.37 11.9364ZM211.52 37.265L210.88 40.862C210.823 41.2603 210.715 41.6497 210.561 42.021C210.428 42.3377 210.227 42.621 209.971 42.8503C209.701 43.0737 209.388 43.2402 209.052 43.3399C208.634 43.4597 208.199 43.5169 207.764 43.5098H201.591L203.149 34.5873H209.322C209.679 34.5359 210.044 34.5638 210.389 34.6692C210.734 34.7745 211.052 34.9546 211.32 35.1968C211.49 35.5106 211.595 35.8554 211.629 36.2107C211.663 36.5659 211.626 36.9245 211.52 37.265ZM214.406 19.1104L213.927 22.1078C213.855 22.5442 213.731 22.9703 213.557 23.3768C213.425 23.6939 213.224 23.9774 212.968 24.2061C212.698 24.4285 212.385 24.5918 212.049 24.6857C211.623 24.8045 211.182 24.8617 210.74 24.8555H204.877L206.306 16.5026H212.169C212.594 16.4939 213.019 16.5512 213.427 16.6724C213.723 16.7635 213.986 16.9368 214.186 17.172C214.364 17.4068 214.472 17.6876 214.496 17.9813C214.508 18.3614 214.468 18.7413 214.376 19.1104H214.406Z"></path>
  </g>
</svg>

</a>

<input type="checkbox" id="hamburger" class="nav-checkbox">
<label class="nav-mobile-button" for="hamburger"><span></span> Menu</label>

<nav class="nav">

  <label class="nav-mobile-button nav-mobile-button--close" for="hamburger"><span></span> close</label>

  <ul class="nav__list ">
    <li>
      <a class="nav__list-link active" href="/handbook/introduction">Handbook</a>

      <ul class="nav__sublist  active"><li>
      <a class="nav__sublist-link active" href="/handbook/introduction">1: Introduction
      </a>
    </li><li>
      <a class="nav__sublist-link" href="/handbook/drive">2: Navigate with Turbo Drive
      </a>
    </li><li>
      <a class="nav__sublist-link" href="/handbook/page_refreshes">3: Smooth page refreshes with morphing
      </a>
    </li><li>
      <a class="nav__sublist-link" href="/handbook/frames">4: Decompose with Turbo Frames
      </a>
    </li><li>
      <a class="nav__sublist-link" href="/handbook/streams">5: Come Alive with Turbo Streams
      </a>
    </li><li>
      <a class="nav__sublist-link" href="/handbook/native">6: Go Native on iOS &amp; Android
      </a>
    </li><li>
      <a class="nav__sublist-link" href="/handbook/building">7: Building Your Turbo Application
      </a>
    </li><li>
      <a class="nav__sublist-link" href="/handbook/installing">8: Installing Turbo in Your Application
      </a>
    </li></ul>

    </li>
    <li>
      <a class="nav__list-link" href="/reference/drive">Reference</a>

      <ul class="nav__sublist "><li>
      <a class="nav__sublist-link" href="/reference/drive">Drive
      </a>
    </li><li>
      <a class="nav__sublist-link" href="/reference/frames">Frames
      </a>
    </li><li>
      <a class="nav__sublist-link" href="/reference/streams">Streams
      </a>
    </li><li>
      <a class="nav__sublist-link" href="/reference/events">Events
      </a>
    </li><li>
      <a class="nav__sublist-link" href="/reference/attributes">Attributes
      </a>
    </li></ul>

    </li>
    <li>
      <a class="nav__list-link" href="https://discuss.hotwired.dev" title="Have a question? Connect with other developers on the Hotwire Discourse community forum.">Community</a>
    </li>
    <li>
      <a class="nav__list-link" href="https://github.com/hotwired/turbo" title="Head over to GitHub for code, bug reports, and pull requests.">Source Code</a>
    </li>
  </ul>

</nav>

  </header>

  <section id="content" class="docs__content grid__custom-item">

    <h1>Introduction</h1>
<p>Turbo bundles several techniques for creating fast, modern, progressively enhanced web applications without using much JavaScript. It offers a simpler alternative to the prevailing client-side frameworks which put all the logic in the front-end and confine the server side of your app to being little more than a JSON API.</p>
<p>With Turbo, you let the server deliver HTML directly, which means all the logic for checking permissions, interacting directly with your domain model, and everything else that goes into programming an application can happen more or less exclusively within your favorite programming language. You’re no longer mirroring logic on both sides of a JSON divide. All the logic lives on the server, and the browser deals just with the final HTML.</p>
<p>You can read more about the benefits of this HTML-over-the-wire approach on the <a href="https://hotwired.dev/">Hotwire site</a>. What follows are the techniques that Turbo brings to make this possible.</p>
<h2 id="turbo-drive%3A-navigate-within-a-persistent-process"><a class="anchor" href="#turbo-drive%3A-navigate-within-a-persistent-process">﹟</a> Turbo Drive: Navigate within a persistent process</h2>
<p>A key attraction with traditional single-page applications, when compared with the old-school, separate-pages approach, is the speed of navigation. SPAs get a lot of that speed from not constantly tearing down the application process, only to reinitialize it on the very next page.</p>
<p>Turbo Drive gives you that same speed by using the same persistent-process model, but without requiring you to craft your entire application around the paradigm. There’s no client-side router to maintain, there’s no state to carefully manage. The persistent process is managed by Turbo, and you write your server-side code as though you were living back in the early aughts – blissfully isolated from the complexities of today’s SPA monstrosities!</p>
<p>This happens by intercepting all clicks on <code>&lt;a href&gt;</code> links to the same domain. When you click an eligible link, Turbo Drive prevents the browser from following it, changes the browser’s URL using the <a href="https://developer.mozilla.org/en-US/docs/Web/API/History">History API</a>, requests the new page using <a href="https://developer.mozilla.org/en-US/docs/Web/API/fetch"><code>fetch</code></a>, and then renders the HTML response.</p>
<p>Same deal with forms. Their submissions are turned into <code>fetch</code> requests from which Turbo Drive will follow the redirect and render the HTML response.</p>
<p>During rendering, Turbo Drive replaces the contents of the <code>&lt;body&gt;</code> element and merges the contents of the <code>&lt;head&gt;</code> element. The JavaScript window and document objects, and the <code>&lt;html&gt;</code> element, persist from one rendering to the next.</p>
<p>While it’s possible to interact directly with Turbo Drive to control how visits happen or hook into the lifecycle of the request, the majority of the time this is a drop-in replacement where the speed is free just by adopting a few conventions.</p>
<h2 id="turbo-frames%3A-decompose-complex-pages"><a class="anchor" href="#turbo-frames%3A-decompose-complex-pages">﹟</a> Turbo Frames: Decompose complex pages</h2>
<p>Most web applications present pages that contain several independent segments. For a discussion page, you might have a navigation bar on the top, a list of messages in the center, a form at the bottom to add a new message, and a sidebar with related topics. Generating this discussion page normally means generating each segment in a serialized manner, piecing them all together, then delivering the result as a single HTML response to the browser.</p>
<p>With Turbo Frames, you can place those independent segments inside frame elements that can scope their navigation and be lazily loaded. Scoped navigation means all interaction within a frame, like clicking links or submitting forms, happens within that frame, keeping the rest of the page from changing or reloading.</p>
<p>To wrap an independent segment in its own navigation context, enclose it in a <code>&lt;turbo-frame&gt;</code> tag. For example:</p>
<pre class="language-html"><code class="language-html"><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>turbo-frame</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>new_message<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span><br>  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>form</span> <span class="token attr-name">action</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>/messages<span class="token punctuation">"</span></span> <span class="token attr-name">method</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>post<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span><br>    ...<br>  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>form</span><span class="token punctuation">&gt;</span></span><br><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>turbo-frame</span><span class="token punctuation">&gt;</span></span></code></pre>
<p>When you submit the form above, Turbo extracts the matching <code>&lt;turbo-frame id="new_message"&gt;</code> element from the redirected HTML response and swaps its content into the existing <code>new_message</code> frame element. The rest of the page stays just as it was.</p>
<p>Frames can also defer loading their contents in addition to scoping navigation. To defer loading a frame, add a <code>src</code> attribute whose value is the URL to be automatically loaded. As with scoped navigation, Turbo finds and extracts the matching frame from the resulting response and swaps its content into place:</p>
<pre class="language-html"><code class="language-html"><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>turbo-frame</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>messages<span class="token punctuation">"</span></span> <span class="token attr-name">src</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>/messages<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span><br>  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>p</span><span class="token punctuation">&gt;</span></span>This message will be replaced by the response from /messages.<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>p</span><span class="token punctuation">&gt;</span></span><br><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>turbo-frame</span><span class="token punctuation">&gt;</span></span></code></pre>
<p>This may sound a lot like old-school frames, or even <code>&lt;iframe&gt;</code>s, but Turbo Frames are part of the same DOM, so there’s none of the weirdness or compromises associated with “real” frames. Turbo Frames are styled by the same CSS, part of the same JavaScript context, and are not placed under any additional content security restrictions.</p>
<p>In addition to turning your segments into independent contexts, Turbo Frames affords you:</p>
<ol>
<li><strong>Efficient caching.</strong> In the discussion page example above, the related topics sidebar needs to expire whenever a new related topic appears, but the list of messages in the center does not. When everything is just one page, the whole cache expires as soon as any of the individual segments do. With frames, each segment is cached independently, so you get longer-lived caches with fewer dependent keys.</li>
<li><strong>Parallelized execution.</strong> Each defer-loaded frame is generated by its own HTTP request/response, which means it can be handled by a separate process. This allows for parallelized execution without having to manually manage the process. A complicated composite page that takes 400ms to complete end-to-end can be broken up with frames where the initial request might only take 50ms, and each of three defer-loaded frames each take 50ms. Now the whole page is done in 100ms because the three frames each taking 50ms run concurrently rather than sequentially.</li>
<li><strong>Ready for mobile.</strong> In mobile apps, you usually can’t have big, complicated composite pages. Each segment needs a dedicated screen. With an application built using Turbo Frames, you’ve already done this work of turning the composite page into segments. These segments can then appear in native sheets and screens without alteration (since they all have independent URLs).</li>
</ol>
<h2 id="turbo-streams%3A-deliver-live-page-changes"><a class="anchor" href="#turbo-streams%3A-deliver-live-page-changes">﹟</a> Turbo Streams: Deliver live page changes</h2>
<p>Making partial page changes in response to asynchronous actions is how we make the application feel alive. While Turbo Frames give us such updates in response to direct interactions within a single frame, Turbo Streams let us change any part of the page in response to updates sent over a WebSocket connection, SSE or other transport. (Think an <a href="http://itsnotatypo.com">imbox</a> that automatically updates when a new email arrives.)</p>
<p>Turbo Streams introduces a <code>&lt;turbo-stream&gt;</code> element with eight basic actions: <code>append</code>, <code>prepend</code>, <code>replace</code>, <code>update</code>, <code>remove</code>, <code>before</code>, <code>after</code>, and <code>refresh</code>. With these actions, along with the <code>target</code> attribute specifying the ID of the element you want to operate on, you can encode all the mutations needed to refresh the page. You can even combine several stream elements in a single stream message. Simply include the HTML you’re interested in inserting or replacing in a <a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Element/template">template tag</a> and Turbo does the rest:</p>
<pre class="language-html"><code class="language-html"><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>turbo-stream</span> <span class="token attr-name">action</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>append<span class="token punctuation">"</span></span> <span class="token attr-name">target</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>messages<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span><br>  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>template</span><span class="token punctuation">&gt;</span></span><br>    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>message_1<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>My new message!<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span><br>  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>template</span><span class="token punctuation">&gt;</span></span><br><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>turbo-stream</span><span class="token punctuation">&gt;</span></span></code></pre>
<p>This stream element will take the <code>div</code> with the new message and append it to the container with the ID <code>messages</code>. It’s just as simple to replace an existing element:</p>
<pre class="language-html"><code class="language-html"><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>turbo-stream</span> <span class="token attr-name">action</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>replace<span class="token punctuation">"</span></span> <span class="token attr-name">target</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>message_1<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span><br>  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>template</span><span class="token punctuation">&gt;</span></span><br>    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation attr-equals">=</span><span class="token punctuation">"</span>message_1<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>This changes the existing message!<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span><br>  <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>template</span><span class="token punctuation">&gt;</span></span><br><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>turbo-stream</span><span class="token punctuation">&gt;</span></span></code></pre>
<p>This is a conceptual continuation of what in the Rails world was first called <a href="https://weblog.rubyonrails.org/2006/3/28/rails-1-1-rjs-active-record-respond_to-integration-tests-and-500-other-things/">RJS</a> and then called <a href="https://signalvnoise.com/posts/3697-server-generated-javascript-responses">SJR</a>, but realized without any need for JavaScript. The benefits remain the same:</p>
<ol>
<li><strong>Reuse the server-side templates</strong>: Live page changes are generated using the same server-side templates that were used to create the first-load page.</li>
<li><strong>HTML over the wire</strong>: Since all we’re sending is HTML, you don’t need any client-side JavaScript (beyond Turbo, of course) to process the update. Yes, the HTML payload might be a tad larger than a comparable JSON, but with gzip, the difference is usually negligible, and you save all the client-side effort it takes to fetch JSON and turn it into HTML.</li>
<li><strong>Simpler control flow</strong>: It’s really clear to follow what happens when messages arrive on the WebSocket, SSE or in response to form submissions. There’s no routing, event bubbling, or other indirection required. It’s just the HTML to be changed, wrapped in a single tag that tells us how.</li>
</ol>
<p>Now, unlike RJS and SJR, it’s not possible to call custom JavaScript functions as part of a Turbo Streams action. But this is a feature, not a bug. Those techniques can easily end up producing a tangled mess when way too much JavaScript is sent along with the response. Turbo focuses squarely on just updating the DOM, and then assumes you’ll connect any additional behavior using <a href="https://stimulus.hotwired.dev">Stimulus</a> actions and lifecycle callbacks.</p>
<h2 id="turbo-native%3A-hybrid-apps-for-ios-%26-android"><a class="anchor" href="#turbo-native%3A-hybrid-apps-for-ios-%26-android">﹟</a> Turbo Native: Hybrid apps for iOS &amp; Android</h2>
<p>Turbo Native is ideal for building hybrid apps for iOS and Android. You can use your existing server-rendered HTML to get baseline coverage of your app’s functionality in a native wrapper. Then you can spend all the time you saved on making the few screens that really benefit from high-fidelity native controls even better.</p>
<p>An application like Basecamp has hundreds of screens. Rewriting every single one of those screens would be an enormous task with very little benefit. Better to reserve the native firepower for high-touch interactions that really demand the highest fidelity. Something like the “New For You” inbox in Basecamp, for example, where we use swipe controls that need to feel just right. But most pages, like the one showing a single message, wouldn’t really be any better if they were completely native.</p>
<p>Going hybrid doesn’t just speed up your development process, it also gives you more freedom to upgrade your app without going through the slow and onerous app store release processes. Anything that’s done in HTML can be changed in your web application, and instantly be available to all users. No waiting for Big Tech to approve your changes, no waiting for users to upgrade.</p>
<p>Turbo Native assumes you’re using the recommended development practices available for iOS and Android. This is not a framework that abstracts native APIs away or even tries to let your native code be shareable between platforms. The part that’s shareable is the HTML that’s rendered server-side. But the native controls are written in the recommended native APIs.</p>
<p>See the <a href="https://github.com/hotwired/turbo-ios">Turbo Native: iOS</a> and <a href="https://github.com/hotwired/turbo-android">Turbo Native: Android</a> repositories for more documentation. See the native apps for HEY on <a href="https://apps.apple.com/us/app/hey-email/id1506603805">iOS</a> and <a href="https://play.google.com/store/apps/details?id=com.basecamp.hey&amp;hl=en_US&amp;gl=US">Android</a> to get a feel for just how good you can make a hybrid app powered by Turbo.</p>
<h2 id="integrate-with-backend-frameworks"><a class="anchor" href="#integrate-with-backend-frameworks">﹟</a> Integrate with backend frameworks</h2>
<p>You don’t need any backend framework to use Turbo. All the features are built to be used directly, without further abstractions. But if you have the opportunity to use a backend framework that’s integrated with Turbo, you’ll find life a lot simpler. <a href="https://github.com/hotwired/turbo-rails">We’ve created a reference implementation for such an integration for Ruby on Rails</a>.</p>
<p><a class="button" href="/handbook/drive">Next: Navigate with Turbo Drive</a></p></section>

  <footer class="docs__footer grid__item grid__item--start-4 grid__item--span-8">

    <footer class="footer">
  <p class="footer__headline">Brought to you by the makers of:</p>
  <ul class="footer__links">
    <li><a href="https://basecamp.com" target="_blank" rel="noopener"><img width="253" height="56" src="/assets/logo-basecamp.svg" alt="Basecamp"></a></li>
    <li><span>and</span></li>
    <li><a href="https://hey.com" target="_blank" rel="noopener"><img width="122" height="56" src="/assets/logo-hey.svg" alt="HEY"></a></li>
  </ul>
  <p class="footer__copyright">© 2024 <a href="https://37signals.com" target="_blank" rel="noopener">37signals</a></p>
</footer>


  </footer>

</main>


  


</body></html>
