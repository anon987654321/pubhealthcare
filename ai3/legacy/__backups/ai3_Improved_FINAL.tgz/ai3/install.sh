
#!/usr/bin/env zsh
# AI3 Installer Script - Enhanced for Non-Technical Users

# Exit on any error and log each command executed
set -e
set -x

# Define directories and variables
INSTALL_DIR="${HOME}/ai3"
LIB_DIR="$INSTALL_DIR/lib"
ASSISTANT_DIR="$INSTALL_DIR/assistants"
LOG_FILE="${INSTALL_DIR}/ai3_install.log"

# Prompt user for API keys if not set
if [[ -z "$OPENAI_API_KEY" ]]; then
  echo "Please enter your OpenAI API Key:"
  read OPENAI_API_KEY
  export OPENAI_API_KEY
fi

if [[ -z "$WEAVIATE_API_KEY" ]]; then
  echo "Please enter your Weaviate API Key:"
  read WEAVIATE_API_KEY
  export WEAVIATE_API_KEY
fi

# Create necessary directories
create_directories() {
  echo "Creating directories..." | tee -a $LOG_FILE
  mkdir -p "$INSTALL_DIR" "$LIB_DIR" "$ASSISTANT_DIR"
}

# Check if dependencies are installed and offer guidance if missing
check_dependencies() {
  echo "Checking for required dependencies..." | tee -a $LOG_FILE
  command -v ruby >/dev/null 2>&1 || { echo "[ERROR] Ruby is not installed. Please install Ruby before continuing."; exit 1; }
  command -v redis-cli >/dev/null 2>&1 || { echo "[ERROR] Redis is not installed. Please install Redis by running 'pkg_add redis'."; exit 1; }
  gem install langchain concurrent-ruby async redis | tee -a $LOG_FILE
}

# Log start of the script
log_start() {
  echo "Starting AI3 installation..." | tee -a $LOG_FILE
  date >> $LOG_FILE
}

# Log completion
log_completion() {
  echo "AI3 installation complete! You can now run AI3 with: ruby ${INSTALL_DIR}/ai3.rb" | tee -a $LOG_FILE
  date >> $LOG_FILE
}

# Main installation steps
main() {
  log_start
  create_directories
  check_dependencies
  log_completion
}

main
