require 'nokogiri'
require 'open-uri'
require 'ferrum'
require 'logger'

class UniversalScraper
  def initialize(options = {})
    raise 'Missing OpenAI API key' unless ENV['OPENAI_API_KEY']

    @options = {
      log_level: Logger::DEBUG,
      timeout: 120,
      retries: 3,
      take_screenshots: true,    # Option to take screenshots for GPT-4v analysis
      screenshot_dir: './screenshots',
      js_wait_time: 5,           # Wait time for JavaScript-rendered pages
      human_like_delay: true,    # Enable human-like delay and interaction
      scroll_pause_time: 2,      # Pause time for scrolling to load new content
      max_scrolls: 10            # Limit the number of scrolls for infinite scroll
    }.merge(options)

    @logger = Logger.new(STDOUT)
    FileUtils.mkdir_p(@options[:screenshot_dir]) if @options[:take_screenshots]
  end

  # Scrapes a webpage, handles infinite scroll, and combines GPT-4v screenshot analysis with GPT-4o page analysis
  def scrape(url)
    retry_count = 0
    begin
      browser = Ferrum::Browser.new(timeout: @options[:timeout])
      browser.goto(url)
      handle_infinite_scroll(browser)  # Handles infinite scroll

      page_content = browser.body
      screenshot_path = take_screenshot(browser, url) if @options[:take_screenshots]

      # Combine visual and page source analysis using GPT-4v and GPT-4o
      refined_content = refine_content(url, page_content, screenshot_path)
      @logger.info("Scraped and analyzed content from: #{url}")
      refined_content

    rescue StandardError => e
      retry_count += 1
      if retry_count <= @options[:retries]
        @logger.warn("Retrying (#{retry_count})...")
        retry
      else
        @logger.error("Error scraping #{url}: #{e.message}")
      end
    ensure
      browser.quit if browser
    end
  end

  private

  # Handles infinite scroll by scrolling the page and waiting for more content to load
  def handle_infinite_scroll(browser)
    return unless infinite_scroll_detected?(browser)

    @logger.info("Infinite scroll detected, handling scroll events...")
    scroll_count = 0

    while scroll_count < @options[:max_scrolls]
      simulate_human_scroll(browser)
      scroll_count += 1
      sleep(@options[:scroll_pause_time])  # Pause for content to load
    end
  end

  # Detect if infinite scroll exists based on the presence of dynamic elements
  def infinite_scroll_detected?(browser)
    browser.evaluate("document.body.scrollHeight > window.innerHeight")
  end

  # Simulates human-like scrolling and random delays
  def simulate_human_scroll(browser)
    browser.execute("window.scrollBy(0, window.innerHeight)")
    random_delay if @options[:human_like_delay]
  end

  # Take a screenshot using Ferrum browser and return the file path
  def take_screenshot(browser, url)
    sanitized_filename = sanitize_filename(url)
    screenshot_path = File.join(@options[:screenshot_dir], "#{sanitized_filename}.png")
    browser.screenshot(path: screenshot_path)
    @logger.info("Screenshot taken: #{screenshot_path}")
    screenshot_path
  end

  # Refine content using GPT-4v (for visual analysis) and GPT-4o (for textual analysis)
  def refine_content(url, page_content, screenshot_path)
    prompt = generate_gpt_prompt(url, page_content, screenshot_path)

    # Assume `@gpt_client` can send queries to both GPT-4v and GPT-4o models
    response = @gpt_client.chat(parameters: { model: "gpt-4", prompt: prompt })
    response
  end

  # Generate a combined prompt for GPT-4v (vision) and GPT-4o (text)
  def generate_gpt_prompt(url, page_content, screenshot_path)
    <<~PROMPT
      You are analyzing the following webpage: #{url}.
      1. Here is the page content (HTML source):
      #{page_content}
      
      2. Here is a screenshot of the page: [#{screenshot_path}].
      
      Based on this information, identify the key targets (text, images, tables) that are most relevant for scraping, focusing on important data.
    PROMPT
  end

  # Randomized delay to mimic human-like behavior
  def random_delay
    delay = rand(1..3)
    @logger.info("Simulating human-like delay of #{delay} seconds...")
    sleep(delay)
  end

  # Sanitize URL to create a safe filename for saving screenshots
  def sanitize_filename(url)
    url.gsub(%r{https?://}, '').gsub(/[^0-9A-Za-z.-]/, '_')[0...255]
  end
end
