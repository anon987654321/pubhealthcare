module ErrorHandling
  def self.log_error(message)
    puts "[ERROR]: #{message}"
  end

  def self.handle_standard_error(error)
    log_error("An error occurred: #{error.message}")
  end
end
