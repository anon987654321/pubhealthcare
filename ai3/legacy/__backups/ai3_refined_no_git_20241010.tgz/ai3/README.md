# AI^3 – Elevate Your Command Line with Supreme Intelligence ⚡️💻

Welcome to **AI^3** – where AI doesn’t just answer questions, it takes charge! Integrating **GPT-4v** and **GPT-4o**, AI^3 will handle everything from filing lawsuits to finding your lost cat (well, almost). It's like having the ultimate AI concierge, right in your terminal.

### Built with Ruby & LangChain 🛠️

Leveraging [Ruby](https://ruby-lang.org/) and [LangChain](https://langchain.com/), **AI^3** plugs right into the [OpenAI Assistants API](https://platform.openai.com/docs/assistants/overview) and **Weaviate** vector search. Because who doesn’t need vectors at the command line?

---

## ✨ Features – AI That Does Real Work 🧠

- **Command-Line Wizardry**: Turn simple English commands into GPT-4v/o magic, automating complex tasks in seconds.
- **Smart Language Understanding**: It’s like that one friend who always knows what you mean, but smarter (and multilingual).
- **Specialized Assistants**: Whether you need legal, medical, or technical help, AI^3’s assistants are domain experts.
- **File & System Integration**: “Hey AI, organize my `~/Projects` folder.” Done.
- **Automated Workflows**: Let AI^3 handle your repetitive tasks like clockwork.
- **Real-Time Data**: AI^3 connects to real-time data streams, so you’re always up to date.
- **Secure and Private**: Your data is handled securely, with strict access controls in place.
- **Cross-Platform Ready**: Whether you’re running OpenBSD or another Unix-like OS, AI^3 performs seamlessly.

---

## 💼 Your AI Team: Specialized Assistants 🤖💼

AI^3’s assistants are ready to assist with expert knowledge:

- **👩‍⚖️ Lawyer**: Get legal advice, draft documents, and analyze court cases.
- **💉 Doctor**: Offers basic medical insights, diagnostic help, and treatment suggestions.
- **🏗️ Architect**: Parametric design with tools like **Mittsu**? Handled.
- **📈 SEO Expert**: Boost your site’s search ranking with tailored strategies.
- **💻 Web Developer**: From code reviews to debugging, your AI developer assistant has it covered.
- **💰 Crypto & Stock Analyst**: Market analysis and investment strategies for the risk-taker in you.
- **🔧 SysAdmin**: Troubleshooting OpenBSD? AI^3’s sysadmin assistant optimizes, configures, and automates.
- **🛡️ Ethical Hacker**: Conduct penetration testing and patch security vulnerabilities.

---

## 🌐 Universal Web Scraper: Smart, Human-Like Scraping 🕵️‍♂️

AI^3’s Universal Scraper integrates **GPT-4v** and **GPT-4o** to scrape complex websites efficiently.

- **Human-Like Interaction**: AI^3 mimics human browsing—scrolling, clicking, and randomizing actions to bypass anti-bot systems.
- **Infinite Scroll Handling**: Handles endless scroll websites, fetching data dynamically.
- **Visual & Textual Analysis**: Combines visual and source code analysis to get only the most valuable data.
- **Adaptive AI**: Learns and improves its scraping techniques as you go.

---

## 🧠 AI with Human-Like Intelligence (Almost) 😏

AI^3 is designed with human-like intelligence:

1. **Personality Tailoring**: Adjusts responses based on your personality for a more personal touch.
2. **Needs-Based Interaction**: Adapts based on Maslow’s Hierarchy—whether you need basic info or in-depth help.
3. **Transactional Communication**: Adjusts conversational style based on context (e.g., formal or friendly).
4. **Cognitive Support**: Need a mental boost? AI^3 uses CBT principles to help you stay on track.

---

## 📚 Realistic Usage Examples: Interactive CLI in Action 💻

```bash
$ ai3.sh
You> What's the current weather in Berlin, Germany?
AI> The current weather in Berlin is 22°C with light rain. Would you like me to forecast the next three days?

$ ai3.sh
You> Check my 'contracts/' folder for unsigned PDFs and send them for e-signing.
AI> Searching 'contracts/'... Found 2 unsigned PDFs. Sending them for e-signature via DocuSign API...

$ ai3.sh
You> Find relevant case law for "intellectual property infringement" in the EU.
AI> Analyzing recent case law... 3 relevant cases found. Would you like a detailed summary or just the key points?

$ ai3.sh
You> Scrape this infinite-scroll website for laptops under $1000.
AI> Scraping laptops under $1000 from 'example.com'... Loaded 50 products. Would you like a CSV export or Markdown summary?

$ ai3.sh
You> Diagnose my server performance in OpenBSD. CPU spikes a lot.
AI> Checking CPU usage logs and system configs... CPU usage spikes during high I/O operations. Recommendation: Adjust buffer sizes in sysctl.conf.

