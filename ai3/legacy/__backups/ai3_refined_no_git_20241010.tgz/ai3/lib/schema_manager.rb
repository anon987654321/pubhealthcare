class SchemaManager
  def initialize
    @schemas = {}
  end

  def define_schema(class_name, properties)
    @schemas[class_name] = properties
    puts "Schema defined for class: #{class_name}"
  end

  def get_schema(class_name)
    @schemas[class_name]
  end
end
