
require_relative 'weaviate_helper'

class EfficientDataRetrieval
