class ExplainableAITools
  def initialize(model)
    @model = model
  end

  def explain_decision(input)
    explanation = @model.explain(input)
    puts "Model Decision Explanation: #{explanation}"
    explanation
  end
end
