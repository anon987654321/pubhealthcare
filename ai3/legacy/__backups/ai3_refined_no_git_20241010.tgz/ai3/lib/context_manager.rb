require 'redis'

class ContextManager
  def initialize(weaviate_helper)
    @contexts = {}
    @weaviate_helper = weaviate_helper
    @redis = Redis.new
  end

  # Updates the user context and stores it in Redis
  def update_context(user_id:, text:)
    @contexts[user_id] ||= []
    @contexts[user_id] << text
    @redis.set(user_id, @contexts[user_id].to_json)  # Store in Redis
    @weaviate_helper.save_context(user_id: user_id, text: text)
    trim_context(user_id) if @contexts[user_id].join(" ").length > 4096
  end

  # Retrieves user context from Redis or memory
  def get_context(user_id:)
    redis_context = @redis.get(user_id)
    @contexts[user_id] = JSON.parse(redis_context) if redis_context
    @contexts[user_id] || []
  end

  private

  # Trims the context to keep it within a reasonable size
  def trim_context(user_id)
    context_text = @contexts[user_id].join(" ")
    while context_text.length > 4096
      @contexts[user_id].shift
      context_text = @contexts[user_id].join(" ")
    end
  end
end
