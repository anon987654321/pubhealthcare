
# Adding Assistant: lawyer.rb
(
  ruby assistants/lawyer.rb
) || echo "[ERROR] Failed to run: ruby assistants/lawyer.rb"
