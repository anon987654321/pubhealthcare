class QueryCache
  def initialize
    @cache = {}
  end

  def cache_query(query, result)
    @cache[query] = result
    puts "Cached result for query: #{query}"
  end

  def fetch_cached_query(query)
    @cache[query]
  end
end
