class PromptManager
  def initialize(api_client)
    @api_client = api_client
  end

  def send_prompt(prompt, user_id)
    response = @api_client.chat(prompt: prompt, user_id: user_id)
    puts "Response: #{response}"
  end
end
